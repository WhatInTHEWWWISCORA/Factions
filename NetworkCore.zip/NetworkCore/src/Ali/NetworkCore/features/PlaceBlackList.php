<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features;

use Ali\NetworkCore\features\type\FeatureModule;
use pocketmine\item\Item;
use pocketmine\utils\SingletonTrait;

class PlaceBlackList extends FeatureModule{
	use SingletonTrait;

	private array $tags = [];

	public function __construct(){
		self::setInstance($this);
	}

	public function addTag(string $tag): void{
		$this->tags[] = $tag;
	}

	public function check(Item $item): bool{
		foreach($this->tags as $tag){
			if($item->getNamedTag()->getTag($tag) !== null){
				return true;
			}
		}

		return false;
	}

}