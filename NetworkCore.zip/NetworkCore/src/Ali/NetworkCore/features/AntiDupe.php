<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features;

use Ali\NetworkCore\features\type\FeatureModule;
use pocketmine\item\Item;
use pocketmine\plugin\Plugin;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use function count;
use const DIRECTORY_SEPARATOR;

class AntiDupe extends FeatureModule{
	use SingletonTrait;
	private const TAG = "ItemIdentifier";
	private int $currentId;
	private Config $config;

	public function __construct(){
		self::setInstance($this);
	}

	public function load(Plugin $plugin):void{
		$this->config = new Config($plugin->getDataFolder() . "data" . DIRECTORY_SEPARATOR . "itemIds.yml", Config::YAML);
		$this->currentId = count($this->config->getAll());
	}

	public function isMasked(Item $item): bool{
		return $item->getNamedTag()->getTag(self::TAG) !== null;
	}

	public function unmask(Item $item): void{
		$item->getNamedTag()->removeTag(self::TAG);
	}

	public function mask(Item $item):void{
		$item->getNamedTag()->setDouble(self::TAG, $this->currentId++);
		$this->config->set($this->currentId - 1, false);
		$this->config->save();
	}

	public function isItemDuped(Item $item):bool{
		$tag = $item->getNamedTag()->getTag(self::TAG);
		if($tag !== null) {
			return $this->config->get($tag->getValue());
		}

		return false;
	}

	public function useItem(Item $item):void{
		$tag = $item->getNamedTag()->getTag(self::TAG);
		if($tag !== null) {
			$this->config->set($tag->getValue());
		}
	}


}