<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features;

use Ali\NetworkCore\features\floatingText\FloatingTextHolder;
use Ali\NetworkCore\features\floatingText\FloatingTextManager;
use Ali\NetworkCore\features\type\FeatureManagerTrait;
use Ali\NetworkCore\features\type\IFeaturesManager;
use Ali\NetworkCore\NetworkCore;

class Features implements IFeaturesManager{
	use FeatureManagerTrait;

	private PlaceBlackList $placeBlackList;
	private FloatingTextManager $floatingTextManager;
	private AntiDupe $antiDupe;
	private FloatingTextHolder $floatingTextHolder;

	public function __construct(NetworkCore $core){
		$this->main = $core;
		$this->register(new PlaceBlackList());
		$this->register(new FloatingTextManager());
		$this->register(new DeathMessages());
		$this->register(new PlayerLoader());
		$this->register(new AntiDupe());
		$this->register(new CPS());
		$this->register(new FloatingTextHolder());
	}

}