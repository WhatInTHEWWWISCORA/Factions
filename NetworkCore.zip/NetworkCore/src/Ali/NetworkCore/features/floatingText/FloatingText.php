<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features\floatingText;

use Ali\NetworkCore\entity\FloatingTextEntity;
use pocketmine\entity\Entity;
use pocketmine\entity\Location;
use pocketmine\world\Position;
use function is_null;

class FloatingText{

	protected ?Entity $entity = null;
	protected string $text = "";

	public function __construct(protected Position $position){
	}

	public function getPosition():Position{
		return $this->position;
	}

	public function getText():string{
		return $this->text;
	}

	public function setText(string $text): void{
		$this->text = $text;
		$this->entity?->setNameTag($this->text);
	}

	public function remove(): void{
		if(!is_null($this->entity) && !$this->entity->isClosed()) {
			$this->entity->flagForDespawn();
		}

		$this->entity = null;
	}

	public function spawn(): void{
		$this->remove();

		$location = new Location($this->position->x, $this->position->y, $this->position->z, $this->position->world, 0,0);
		$this->entity = new FloatingTextEntity($location);
		$this->entity->setNameTagVisible();
		$this->entity->setNameTag($this->text);
		$this->entity->spawnToAll();

	}

}