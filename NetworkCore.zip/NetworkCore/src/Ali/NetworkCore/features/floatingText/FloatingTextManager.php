<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features\floatingText;

use Ali\NetworkCore\features\type\FeatureModule;
use pocketmine\event\EventPriority;
use pocketmine\event\world\ChunkLoadEvent;
use pocketmine\event\world\ChunkUnloadEvent;
use pocketmine\plugin\Plugin;
use pocketmine\utils\SingletonTrait;
use function spl_object_hash;

class FloatingTextManager extends FeatureModule{
	use SingletonTrait;

	private array $floatingTexts = [];

	public function __construct(){
		self::setInstance($this);
	}

	public function enable(Plugin $plugin):void{
		$plugin->getServer()->getPluginManager()->registerEvent(ChunkUnloadEvent::class, function(ChunkUnloadEvent $event): void{
			$texts = $this->floatingTexts[$event->getWorld()->getFolderName()][$event->getChunkX()][$event->getChunkZ()] ?? [];
			/** @var FloatingText[] $texts */
			foreach($texts as $text){
				$text->remove();
			}
		},EventPriority::MONITOR, $plugin);

		$plugin->getServer()->getPluginManager()->registerEvent(ChunkLoadEvent::class, function(ChunkLoadEvent $event): void{
			$texts = $this->floatingTexts[$event->getWorld()->getFolderName()][$event->getChunkX()][$event->getChunkZ()] ?? [];
			/** @var FloatingText[] $texts */
			foreach($texts as $text){
				$text->spawn();
			}
		},EventPriority::MONITOR, $plugin);
	}

	public function addFloatingText(FloatingText $floatingText): void{
		$chunkX = $floatingText->getPosition()->getFloorX() >> 4;
		$chunkZ = $floatingText->getPosition()->getFloorZ() >> 4;
		$this->floatingTexts[$floatingText->getPosition()->getWorld()->getFolderName()][$chunkX][$chunkZ][spl_object_hash($floatingText)] = $floatingText;
		if($floatingText->getPosition()->getWorld()->isChunkLoaded($chunkX, $chunkZ)) {
			$floatingText->spawn();
		}
	}

	public function removeFloatingText(FloatingText $floatingText): void{
		$chunkX = $floatingText->getPosition()->getFloorX() >> 4;
		$chunkZ = $floatingText->getPosition()->getFloorZ() >> 4;
		unset($this->floatingTexts[$floatingText->getPosition()->getWorld()->getFolderName()][$chunkX][$chunkZ][spl_object_hash($floatingText)]);
		$floatingText->remove();
	}


}