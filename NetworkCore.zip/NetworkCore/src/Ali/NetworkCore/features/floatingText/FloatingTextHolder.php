<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features\floatingText;

use Ali\NetworkCore\features\type\FeatureModule;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\utils\world\WorldUtils;
use pocketmine\plugin\Plugin;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\Position;
use function str_replace;
use const DIRECTORY_SEPARATOR;

class FloatingTextHolder extends FeatureModule{
	use SingletonTrait;

	private Config $config;
	/**
	 * @var FloatingText[]
	 */
	private array $texts = [];

	public function __construct(){
		self::setInstance($this);
	}

	public function load(Plugin $plugin):void{
		$this->config = new Config($plugin->getDataFolder()."data".DIRECTORY_SEPARATOR."text.yml");
	}

	public function enable(Plugin $plugin):void{
		foreach($this->config->getAll() as $key => $text){
			$pos = WorldUtils::DisposeVector($key);
			if($pos->world !== null) {
				$this->addText($pos, $text);
			}
		}
	}

	public function addText(Position $position, string $text): void{
		$this->texts[] = $t = new FloatingText($position);
		$t->setText(str_replace("{line}", "\n", $text));
		FloatingTextManager::getInstance()->addFloatingText($t);
		$this->config->set(WorldUtils::HashPosition($position), $text);
		$this->config->save();
	}

	public function deleteText(int $id): bool{
		$text = $this->texts[$id] ?? null;

		if($text !== null){
			$this->config->remove(WorldUtils::HashPosition($text->getPosition()));
			FloatingTextManager::getInstance()->removeFloatingText($text);
			unset($this->texts[$id]);
			$this->config->save();
			return true;
		}

		return false;
	}

	public function editText(int $id, string $text): bool{
		$t = $this->texts[$id] ?? null;

		if($t !== null){
			$t->setText($text);
			$this->config->set(WorldUtils::HashPosition($t->getPosition()), str_replace("{line}", "\n", $text));
			$this->config->save();
			return true;
		}

		return false;
	}

	public function getTexts(): array{
		return $this->texts;
	}

}