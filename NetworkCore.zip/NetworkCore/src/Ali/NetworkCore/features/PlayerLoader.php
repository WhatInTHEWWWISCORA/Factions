<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features;

use Ali\NetworkCore\event\PlayerPreJoinEvent;
use Ali\NetworkCore\features\type\FeatureModule;
use Ali\NetworkCore\libraries\simplepackethandler\BaseInterceptor;
use pocketmine\network\mcpe\NetworkSession;
use pocketmine\network\mcpe\protocol\PlayStatusPacket;
use pocketmine\network\mcpe\protocol\SetLocalPlayerAsInitializedPacket;
use pocketmine\plugin\Plugin;
use function is_null;

class PlayerLoader extends FeatureModule{

	private array $spawned = [];

	private const WAITING = 1;
	private const RECEIVED = 2;

	public function enable(Plugin $plugin):void{
		BaseInterceptor::getInstance()->getInterceptor()->interceptOutgoing(function(PlayStatusPacket $packet, NetworkSession $networkSession): bool{
			$player = $networkSession->getPlayer();
			if(is_null($player)){
				return true;
			}

			if(!$player->spawned) {
				$ev = new PlayerPreJoinEvent($player);
				$ev->call();

				$player->getNetworkSession()->setHandler(null);
				$this->spawned[$player->getId()] = self::WAITING;
				$ev->getWaitGroup()->then(function() use ($player):void{
					if(!$player->isConnected()) {
						return;
					}

					$value = $this->spawned[$player->getId()];
					if($value === self::RECEIVED) {
						$player->getNetworkSession()->getHandler()->handleSetLocalPlayerAsInitialized(SetLocalPlayerAsInitializedPacket::create($player->getId()));
					}
					unset($this->spawned[$player->getId()]);
				});
			}

			return true;
		});

		BaseInterceptor::getInstance()->getInterceptor()->interceptIncoming(function(SetLocalPlayerAsInitializedPacket $packet, NetworkSession $networkSession): bool{
			$player = $networkSession->getPlayer();
			if(is_null($player)){
				return false;
			}

			if(isset($this->spawned[$player->getId()])){
				$this->spawned[$player->getId()] = self::RECEIVED;
				return false;
			}

			return true;
		});
	}

}