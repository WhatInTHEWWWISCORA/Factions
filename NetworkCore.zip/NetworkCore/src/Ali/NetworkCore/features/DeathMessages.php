<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features;

use Ali\NetworkCore\features\type\FeatureModule;
use pocketmine\entity\Entity;
use pocketmine\entity\Living;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use function str_replace;

class DeathMessages extends FeatureModule{
	use SingletonTrait;

	private array $deriveMessages;

	public function __construct(){
		self::setInstance($this);
	}

	public function load(Plugin $plugin):void{
		$deathMessagesConfig = new Config($plugin->getDataFolder() . "deathMessages.yml");
		$this->deriveMessages = $deathMessagesConfig->getNested("deathMessages");
	}


	public function get(string $derive, Living $victim, Entity $murderer = null): string {
		$item = null;
		if($derive === "death.attack.player"){
			if($murderer instanceof Player){
				if(!$murderer->getInventory()->getItemInHand()->isNull()){
					$derive = "death.attack.player.item";
					$item = $murderer->getInventory()->getItemInHand();
					$item = $item->hasCustomName() ? $item->getCustomName() : $item->getName();
				}
			}
		}

		$deriveMessage = str_replace("{victim}", $victim->getName(), $this->deriveMessages[$derive]);
		if(!$murderer instanceof Living){
			return $deriveMessage;
		}
		$deriveMessage = str_replace(["{murdererHealth}", "{murderer}"], [(string) $murderer->getHealth(), $murderer->getName()],$deriveMessage);

		if(!isset($item)){
			return $deriveMessage;
		}

		return str_replace("{itemUsed}", ($item ?? $murderer->getInventory()->getItemInHand()->getName())."§r", $deriveMessage);
	}

}