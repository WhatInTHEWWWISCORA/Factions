<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features\type;

interface IFeaturesManager{

	public function enable():void;

	public function register(FeatureModule $module):void;

	public function save():void;

}