<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features\type;

use pocketmine\plugin\Plugin;

class FeatureModule{

	public function load(Plugin $plugin):void{
	}


	public function enable(Plugin $plugin):void{
	}


	public function save():void{
	}
}