<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features\type;

use pocketmine\plugin\Plugin;

trait FeatureManagerTrait{

	private array $modules;
	protected Plugin $main;

	public function enable():void{
		foreach($this->modules as $module) {
			$module->enable($this->main);
		}
	}

	public function register(FeatureModule $module):void{
		$this->modules[] = $module;
		$module->load($this->main);
	}


	public function save():void{
		foreach($this->modules as $module) {
			$module->save();
		}
	}

}