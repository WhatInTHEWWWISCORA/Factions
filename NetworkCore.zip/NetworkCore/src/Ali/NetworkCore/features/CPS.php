<?php
declare(strict_types=1);

namespace Ali\NetworkCore\features;

use Ali\NetworkCore\features\type\FeatureModule;
use Ali\NetworkCore\libraries\simplepackethandler\BaseInterceptor;
use Ali\NetworkCore\player\OnlineSession;
use Ali\NetworkCore\player\SessionManager;
use pocketmine\network\mcpe\NetworkSession;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemOnEntityTransactionData;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\plugin\Plugin;
use function is_null;

class CPS extends FeatureModule{

	public function enable(Plugin $plugin):void{
		$interceptor = BaseInterceptor::getInstance()->getInterceptor();
		$interceptor->interceptIncoming(function(LevelSoundEventPacket $packet, NetworkSession $networkSession): bool{
			$player = $networkSession->getPlayer();
			if(is_null($player)){
				return false;
			}

			if($packet->sound === LevelSoundEvent::ATTACK_NODAMAGE){
				$session = SessionManager::get()->getSession($player);
				if(is_null($session)){
					return false;
				}

				if(!$this->checkCPS($session)) {
					return false;
				}
			}

			return true;
		});

		$interceptor->interceptIncoming(function(InventoryTransactionPacket $packet, NetworkSession $networkSession): bool{
			$player = $networkSession->getPlayer();
			if(is_null($player)){
				return false;
			}

			$trData = $packet->trData;
			if($trData->getTypeId() === UseItemOnEntityTransactionData::ID){
				/** @var UseItemOnEntityTransactionData $trData */
				$session = SessionManager::get()->getSession($player);

				if(is_null($session)){
					return false;
				}

				if(!$this->checkCPS($session)){
					return false;
				}
			}

			return true;
		});
	}

	private function checkCPS(OnlineSession $session): bool{
		$session->getCps()->addBalance(1);
		if($session->getCps()->getBalance() >= 19){
			if($session->getCps()->getBalance() > 100){
				$session->getPlayer()->kick("§fYou've ran into a problem, please open a ticket at §ddiscord.gg/Cora\nError Code: 1");
			}
			return false;
		}

		return true;
	}

}