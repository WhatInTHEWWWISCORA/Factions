<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\TradeAPI;

use Ali\NetworkCore\libraries\TradeAPI\inventory\MerchantInventory;
use Ali\NetworkCore\libraries\TradeAPI\session\TradeSessionManager;
use Ali\NetworkCore\libraries\TradeAPI\trade\TradeRecipes;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class TradeAPI extends PluginBase implements Listener{

	public static function register(PluginBase $plugin):void{
		new TradeSessionManager($plugin);
	}

	public static function send(Player $player, TradeRecipes $recipes, string $name = ""):void{
		$menu = new MerchantInventory($recipes, $name);
		$player->setCurrentWindow($menu);
	}

}