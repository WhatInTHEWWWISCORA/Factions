<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\TradeAPI\inventory;

use Ali\NetworkCore\libraries\TradeAPI\session\TradeSessionManager;
use Ali\NetworkCore\libraries\TradeAPI\trade\TradeRecipes;
use pocketmine\block\inventory\BlockInventory;
use pocketmine\entity\Entity;
use pocketmine\inventory\SimpleInventory;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\RemoveActorPacket;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataCollection;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\network\mcpe\protocol\types\entity\IntMetadataProperty;
use pocketmine\network\mcpe\protocol\UpdateTradePacket;
use pocketmine\player\Player;
use pocketmine\world\Position;

class MerchantInventory extends SimpleInventory implements BlockInventory{
	private int $id;

	public function __construct(private TradeRecipes $recipes, private string $name){
		$this->id = Entity::nextRuntimeId();
		parent::__construct(2);
	}

	public function onOpen(Player $who):void{
		parent::onOpen($who);

		$properties = new EntityMetadataCollection();
		$properties->set(EntityMetadataProperties::TRADE_TIER, new IntMetadataProperty(0));
		$properties->set(EntityMetadataProperties::TRADE_XP, new IntMetadataProperty(0));
		$properties->set(EntityMetadataProperties::MAX_TRADE_TIER, new IntMetadataProperty(0));
		$properties->set(EntityMetadataProperties::TRADING_PLAYER_EID, new IntMetadataProperty(-1));
		$properties->setGenericFlag(EntityMetadataFlags::INVISIBLE, true);

		$networkSession = $who->getNetworkSession();
		$networkSession->sendDataPacket(AddActorPacket::create($this->id, $this->id, EntityIds::NPC, $who->getPosition()->add(0, 0, 0), null, 0, 0, 0, 0, [], $properties->getAll(), null, []));
		$networkSession->sendDataPacket(UpdateTradePacket::create(-1, -1, -1, 0, $this->id, 0, $this->name, true, false, $this->recipes->__nbt()));

		TradeSessionManager::getInstance()->getSession($who)->setCurrentWindow($this);
	}


	public function trade(Player $who, int $recipe):void{
		$firstItem = $this->getItem(0);
		$secondItem = $this->getItem(1);
		$recipe = $this->recipes->getRecipes()[$recipe] ?? null;

		if($recipe !== null) {
			$firstInput = $recipe->getFirstInput();
			$secondInput = $recipe->getSecondInput();

			if($firstInput->isNull() && $secondInput->isNull()) {
				goto trade;
			}

			if($secondInput->isNull() && ($firstInput->equals($item = $firstItem) || $firstInput->equals($item = $secondItem))) {
				$slot = $item === $firstItem ? 0 : 1;
				$item->pop($firstInput->getCount());

				$this->setItem($slot, $item);
				goto trade;
			}

			if($firstInput->isNull() && ($secondInput->equals($item = $firstItem) || $secondInput->equals($item = $secondItem))) {
				$slot = $item === $firstItem ? 0 : 1;
				$item->pop($firstInput->getCount());

				$this->setItem($slot, $item);
				goto trade;
			}

			if($firstInput->equals($firstItem) && $secondInput->equals($secondItem)) {
				$firstItem->pop($firstInput->getCount());
				$secondItem->pop($secondInput->getCount());

				$this->setItem(0, $firstItem);
				$this->setItem(1, $secondItem);
				goto trade;
			}


			if(false) {
				trade:
				foreach($who->getInventory()->addItem($recipe->getOutput()) as $item) {
					$who->getWorld()->dropItem($who->getPosition(), $item);
				}
			}
		}
	}

	public function onClose(Player $who):void{
		foreach($this->getContents() as $item) {
			$who->getInventory()->addItem($item);
		}

		$who->getNetworkSession()->sendDataPacket(RemoveActorPacket::create($this->id));
		TradeSessionManager::getInstance()->getSession($who)->setCurrentWindow(null);
	}

	public function getHolder():Position{
		return new Position(0, -1, 0, null);
	}
}