<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\TradeAPI\trade;

use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\network\mcpe\protocol\types\CacheableNbt;
use function array_map;

class TradeRecipes{

	private const RECIPES = "Recipes";
	private const XP_REQUIREMENTS = "TierExpRequirements";

	private CacheableNbt $nbt;

	private array $recipes = [];

	public function __construct(){}

	public function __nbt(): CacheableNbt{
		return $this->nbt;
	}

	/**
	 * @return TradeRecipe[]
	 */
	public function getRecipes(): array{
		return $this->recipes;
	}

	public function addRecipe(TradeRecipe $recipe): void{
		$this->recipes[] = $recipe;
		$recipe->__addListener(function(): void{
			$this->update();
		});
		$this->update();
	}

	private function update(): void{
		$tag = CompoundTag::create()->setTag(self::RECIPES, new ListTag(array_map(function(TradeRecipe $recipe):CompoundTag{
			return $recipe->__nbt();
		}, $this->recipes)))->setTag(self::XP_REQUIREMENTS, new ListTag([]));

		$this->nbt = new CacheableNbt($tag);
	}

}