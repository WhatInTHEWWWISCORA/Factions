<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\TradeAPI\trade;

use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use Closure;
use function spl_object_hash;

class TradeRecipe{

	private const BUY_A = "buyA";
	private const SELL = "sell";
	private const BUY_B = "buyB";
	private const TIER = "tier";
	private const BUY_COUNT_A = "buyCountA";
	private const BUY_COUNT_B = "buyCountB";
	private const USES = "uses";
	private const REWARD_XP = "rewardExp";
	private const DEMAND = "demand";
	private const TRADER_XP = "traderExp";
	private const PRICE_MULTIPLIER_A = "priceMultiplierA";
	private const PRICE_MULTIPLIER_B = "priceMultiplierB";

	private CompoundTag $nbt;

	private array $listeners = [];

	public function __construct(private Item $firstInput, private Item $secondInput, private Item $output){
		$this->onChanged();
	}

	public function getFirstInput():Item{
		return $this->firstInput;
	}

	public function getSecondInput():Item{
		return $this->secondInput;
	}

	public function setInput(Item $firstInput, Item $secondInput = null):void{
		$this->firstInput = $firstInput;
		$this->secondInput = $secondInput;
		$this->onChanged();
	}


	public function getOutput():Item{
		return $this->output;
	}

	public function setOutput(Item $sell):void{
		$this->output = $sell;
		$this->onChanged();
	}

	public function __addListener(Closure $listener): void{
		$this->listeners[spl_object_hash($listener)] = $listener;
	}

	public function __nbt(): CompoundTag{
		return $this->nbt;
	}

	private function onChanged():void{
		$this->nbt = $tag = new CompoundTag();

		if(!$this->firstInput->isNull()) {
			$tag->setTag(self::BUY_A, $this->firstInput->nbtSerialize());
			$tag->setInt(self::BUY_COUNT_A, $this->firstInput->getCount());
			$tag->setFloat(self::PRICE_MULTIPLIER_A, 1.0);
		}

		$tag->setTag(self::SELL, $this->output->nbtSerialize());

		if(!$this->secondInput->isNull()) {
			$tag->setTag(self::BUY_B, $this->secondInput->nbtSerialize());
			$tag->setInt(self::BUY_COUNT_B, $this->secondInput->getCount());
			$tag->setFloat(self::PRICE_MULTIPLIER_B, 1.0);
		}

		//TODO?
		$tag->setInt(self::TIER, 0);
		$tag->setInt(self::USES, -100);
		$tag->setInt(self::REWARD_XP, 0);
		$tag->setInt(self::DEMAND, 0);
		$tag->setInt(self::TRADER_XP, 0);
		foreach($this->listeners as $listener) {
			$listener();
		}
	}



}