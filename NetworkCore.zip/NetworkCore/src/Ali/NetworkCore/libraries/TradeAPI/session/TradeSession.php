<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\TradeAPI\session;

use pocketmine\inventory\Inventory;
use pocketmine\player\Player;
use Ali\NetworkCore\libraries\TradeAPI\inventory\MerchantInventory;

final class TradeSession{

	private ?MerchantInventory $inventory = null;

	public function __construct(private Player $player){}

	public function setCurrentWindow(?Inventory $inventory):void{
		$this->inventory = $inventory;
	}

	public function getCurrentWindow():?MerchantInventory{
		return $this->inventory;
	}
}