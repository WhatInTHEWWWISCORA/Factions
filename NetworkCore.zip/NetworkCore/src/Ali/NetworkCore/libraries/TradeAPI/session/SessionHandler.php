<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\TradeAPI\session;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\network\mcpe\protocol\ContainerClosePacket;
use pocketmine\network\mcpe\protocol\InventoryContentPacket;
use pocketmine\network\mcpe\protocol\InventorySlotPacket;
use pocketmine\network\mcpe\protocol\types\ActorEvent;
use function is_null;

class SessionHandler implements Listener{

	public function onJoin(PlayerJoinEvent $event): void{
		TradeSessionManager::getInstance()->__createSession($event->getPlayer());
	}

	public function onDataPacketSend(DataPacketSendEvent $event): void{
		$packet = $event->getPackets()[0];
		$networkSession = $event->getTargets()[0];
		$player = $networkSession->getPlayer();

		if(is_null($player)) {
			return;
		}

		$session = TradeSessionManager::getInstance()->getSession($player);
		if(is_null($session)) {
			return;
		}

		$inventory = $session->getCurrentWindow();
		if(is_null($inventory)) {
			return;
		}

		switch($packet->pid()){
			case InventoryContentPacket::NETWORK_ID:
				/** @var InventoryContentPacket $packet */

				$currentId = $networkSession->getInvManager()->getWindowId($inventory);
				if($currentId === $packet->windowId) {
					foreach($packet->items as $slot => $item) {
						$networkSession->sendDataPacket(InventorySlotPacket::create(255, $slot, $item));
					}

					$event->cancel();
				}
				break;
			case InventorySlotPacket::NETWORK_ID:
				/** @var InventorySlotPacket $packet */
				$currentId = $networkSession->getInvManager()->getWindowId($inventory);
				if($currentId === $packet->windowId) {
					$packet->windowId = 255;
				}
			break;
		}
	}

	public function onDataPacket(DataPacketReceiveEvent $event): void{
		$packet = $event->getPacket();
		$networkSession = $event->getOrigin();
		$player = $networkSession->getPlayer();

		if(is_null($player)) {
			return;
		}

		$session = TradeSessionManager::getInstance()->getSession($player);
		if(is_null($session)) {
			return;
		}

		$inventory = $session->getCurrentWindow();
		if(is_null($inventory)) {
			return;
		}

		switch($packet->pid()){
			case ContainerClosePacket::NETWORK_ID:
				/** @var ContainerClosePacket $packet */ if($packet->windowId === 255) {
				$packet->windowId = $networkSession->getInvManager()->getWindowId($inventory);
			}
				break;
			case ActorEventPacket::NETWORK_ID:
				/** @var ActorEventPacket $packet */ if($packet->eventId === ActorEvent::COMPLETE_TRADE) {
				$inventory->trade($player, $packet->eventData);
				$event->cancel();
			}
				break;
		}

	}


}