<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\TradeAPI\session;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

final class TradeSessionManager{

	/**
	 * @var TradeSession[]
	 */
	private array $sessions = [];
	private static self $instance;

	public function __construct(PluginBase $plugin){
		self::$instance = $this;
		$plugin->getServer()->getPluginManager()->registerEvents(new SessionHandler(), $plugin);
	}

	public static function getInstance(): self{
		return self::$instance;
	}

	/**
	 * @param Player $player
	 * @return void
	 *
	 * @internal
	 */
	public function __createSession(Player $player): void{
		$this->sessions[$player->getId()] = new TradeSession($player);
	}

	public function getSession(Player $player): ?TradeSession{
		return $this->sessions[$player->getId()] ?? null;
	}

	/**
	 * @param Player $player
	 * @return void
	 *
	 * @internal
	 */
	public function __destroySession(Player $player): void{
		unset($this->sessions[$player->getId()]);
	}

}