<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\settings;

use pocketmine\plugin\Plugin;

class Settings{

	public static ?Plugin $plugin = null;

	public static function register(Plugin $plugin): void{
		self::$plugin = $plugin;
	}

}