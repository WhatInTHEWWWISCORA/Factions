<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\settings;

use Ali\NetworkCore\libraries\invmenu\InvMenu;
use Ali\NetworkCore\libraries\invmenu\transaction\DeterministicInvMenuTransaction;
use Ali\NetworkCore\libraries\invmenu\type\InvMenuTypeIds;
use Ali\NetworkCore\libraries\pmforms\CustomForm;
use Ali\NetworkCore\libraries\pmforms\CustomFormResponse;
use Ali\NetworkCore\libraries\pmforms\element\Label;
use Ali\NetworkCore\libraries\pmforms\MenuForm;
use Ali\NetworkCore\libraries\pmforms\MenuOption;
use Ali\NetworkCore\libraries\settings\setting\type\Setting;
use Ali\NetworkCore\utils\player\DeviceUtils;
use Ali\NetworkCore\utils\world\SoundUtils;
use Closure;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;
use function count;
use function is_null;

class SettingsHolder{


	/**
	 * @var self[]
	 */
	private array $holders = [];

	/**
	 * @var Setting[]
	 */
	private array $settings = [];

	public function __construct(private string $name, private Item $item, private string $description = ""){
		if(!$item->hasCustomName()) {
			$item->setCustomName(C::RESET . $name);
		}
	}

	/**
	 * @return string
	 */
	public function getName():string{
		return $this->name;
	}

	/**
	 * @return Item
	 */
	public function getItem():Item{
		return $this->item;
	}

	public function addSetting(Setting $setting):void{
		$this->settings[] = $setting;
	}

	public function addHolder(SettingsHolder $holder):void{
		$this->holders[] = $holder;
	}

	public function send(Player $player, ?Closure $closure = null, ?InvMenu $invMenu = null):void{
		if(DeviceUtils::isMobile($player)) {
			if(count($this->holders) > 0) {
				$options = [];

				$holders = $this->holders;
				foreach($holders as $holder) {
					$options[] = new MenuOption($holder->getName());
				}

				$settings = $this->settings;
				foreach($settings as $setting) {
					$options[] = new MenuOption($setting->getButtonName());
				}

				$player->sendForm(new MenuForm($this->name, $this->description, $options, function(Player $player, int $data) use ($holders, $settings, $closure):void{
					if($data < count($holders)) {
						$holder = $holders[$data];
						$holder->send($player, function(Player $player) use ($closure):void{
							$this->send($player, $closure);
						});
						return;
					}

					$data -= count($holders);
					$setting = $settings[$data];

					if($setting->isButtonSubmittable()) {
						$setting->handleFormClick();
						$setting->onChanged();
					}else{
						$player->sendForm(self::createCustomForm($setting->getName(), [$setting], function(Player $player) use ($closure):void{
							$this->send($player, $closure);
						}));
						return;
					}

					if($closure !== null) {
						$closure($player);
					}
				}, $closure));
			}else{
				$player->sendForm(self::createCustomForm($this->name, $this->settings, $closure, $this->description));
			}
			return;
		}

		if(is_null($invMenu)) {
			$menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
			$menu->setName($this->name);
			$menu->send($player);
		}else{
			$menu = $invMenu;
		}


		$contents = [];

		$holders = $this->holders;
		foreach($holders as $holder) {
			$contents[] = $holder->getItem();
		}

		$settings = $this->settings;
		foreach($settings as $setting) {
			$setting->onOpen();
			$contents[] = $setting->getItem();
		}


		if($closure !== null) {
			$contents[26] = VanillaBlocks::BARRIER()->asItem()->setCustomName(C::RESET.C::RED."Back");
		}

		$menu->getInventory()->setContents($contents);
		$menu->setListener(InvMenu::readonly(function(DeterministicInvMenuTransaction $transaction) use ($holders, $settings, $closure, $menu):void{
			$action = $transaction->getAction();
			$slot = $action->getSlot();
			$player = $transaction->getPlayer();

			if($slot === 26 && $closure !== null) {
				SoundUtils::click($player);
				$closure($player, $menu);
				return;
			}

			if($slot < count($holders)) {
				SoundUtils::click($player);
				$holder = $holders[$slot];
				$holder->send($transaction->getPlayer(), function(Player $player, InvMenu $menu) use ($closure):void{
					$this->send($player, $closure, $menu);
				},$menu);
				return;
			}

			$setting = $settings[$slot] ?? null;

			if($setting !== null) {
				if($setting->isButtonSubmittable()) {
					if($setting->handleMenuClick($slot, $action->getInventory())){
						SoundUtils::enderMan($player);
					}else{
						SoundUtils::fail($player);
					}
					$setting->onChanged();
				}else{
					SoundUtils::click($player);
					$listener = $menu->getListener();
					$close_listener = $menu->getInventoryCloseListener();
					$callBack = function(Player $player, InvMenu $menu) use ($closure, $listener, $close_listener):void{
						$menu->setListener($listener);
						$menu->setInventoryCloseListener($close_listener);
						$this->send($player, $closure, $menu);
					};

					if(($cMenu = $setting->getCustomMenu($menu, $callBack)) !== null) {
						if($menu !== $cMenu) {
							$cMenu->send($player);
							$cMenu->setInventoryCloseListener(function(Player $player) use ($menu, $closure):void{
								$menu->send($player);
								$this->send($player, $closure, $menu);
							});
						}
						return;
					}

					$transaction->getPlayer()->removeCurrentWindow();
					$transaction->then(function() use ($player, $setting, $closure, $menu){
						if($player->isConnected()) {
							$player->sendForm(self::createCustomForm($setting->getName(), [$setting], function(Player $player) use ($menu, $closure):void{
								$menu->send($player);
								$this->send($player, $closure, $menu);
							}, $this->description));
						}
					});
				}
			}
		}));
	}

	public static function sendSetting(Player $player, Setting $setting): void{
		$setting->onOpen();
		if(DeviceUtils::isMobile($player) || is_null(($cMenu = $setting->getCustomMenu(null, null)))) {
			$player->sendForm(self::createCustomForm($setting->getName(), [$setting], function(Player $player):void{

			}));
		}else{
			$cMenu->send($player);
		}
	}

	/**
	 * @param string $name
	 * @param Setting[] $settings
	 * @param Closure|null $closure
	 * @param string $description
	 * @return CustomForm
	 */
	public static function createCustomForm(string $name, array $settings, ?Closure $closure = null, string $description = ""): CustomForm{
		$options = [];

		if($description !== "") {
			$options[] = new Label('__formDescription', $description);
		}

		$mappings = [];
		$i = 0;
		foreach($settings as $setting) {
			$number = 0;
			$setting->onOpen();
			foreach($setting->getCustomFormComponents() as $component) {
				$mappings[$i] = [$setting, $number];
				$options[] = $component;

				$number++;
				$i++;
			}
		}

		return new CustomForm($name, $options, function(Player $player, CustomFormResponse $response) use ($settings, $closure, $mappings):void{
			$responses = $response->getAll();

			$i = 0;
			foreach($responses as $response){
				$data = $mappings[$i];

				$setting = $data[0];
				$number = $data[1];
				$setting->handleFormResponse($number, $response);
				$i++;
			}

			if($closure !== null) {
				$closure($player);
			}
		}, $closure);
	}

}