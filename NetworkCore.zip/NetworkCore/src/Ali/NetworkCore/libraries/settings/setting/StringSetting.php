<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\settings\setting;

use Ali\NetworkCore\libraries\pmforms\element\CustomFormElement;
use Ali\NetworkCore\libraries\pmforms\element\Input;
use Ali\NetworkCore\libraries\settings\setting\type\Setting;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use pocketmine\utils\TextFormat as C;

class StringSetting extends Setting{

	public function __construct(string $identifier, string $name, Item $item, mixed &$value, ?Closure $onOpen = null){
		parent::__construct($identifier, $name, $item, $value, $onOpen);
		$this->item->setCustomName(TextFormat::RESET . $this->name);
		$this->updateItem();
	}

	private function updateItem(): void{
		$this->item->setLore([
			"",
			C::RESET.C::GOLD."Current".C::GRAY.": ".C::WHITE.($this->value === "" ? C::YELLOW."None" : $this->value)
		]);
	}

	public function isButtonSubmittable():bool{
		return false;
	}

	public function getCustomFormComponents():array{
		return [new Input($this->name, $this->name, "",$this->value)];
	}

	public function handleFormClick():bool{
		return true;
	}

	public function handleFormResponse(int $key, mixed $value):bool{
		$this->setValue($value);
		$this->updateItem();
		return true;
	}

	public function handleMenuClick(int $slot, Inventory $inventory): bool{
		return false;
	}
}