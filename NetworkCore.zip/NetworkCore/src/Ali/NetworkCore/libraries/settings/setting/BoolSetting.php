<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\settings\setting;

use Ali\NetworkCore\libraries\pmforms\element\Dropdown;
use Ali\NetworkCore\libraries\settings\setting\type\Setting;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat as C;
use Closure;

class BoolSetting extends Setting{

	public function __construct(string $identifier,string $name, Item $item, mixed &$value, ?Closure $onOpen = null){
		parent::__construct($identifier,$name, $item, $value, $onOpen);
		$item->setCustomName(C::RESET . $this->name.C::RESET);
		$this->setLore($item, $value);
	}

	public function getButtonName():string{
		return $this->getCustomFormComponents()[0]->getName();
	}

	public function isButtonSubmittable():bool{
		return true;
	}

	public function getCustomFormComponents():array{
		return [new Dropdown($this->name, $this->name, [
			C::GREEN . "Enabled",
			C::RED . "Disabled"
		], $this->value ? 0 : 1)];
	}

	public function handleFormClick():bool{
		$this->value = !$this->value;
		return true;
	}

	public function handleFormResponse(int $key, mixed $value):bool{
		$this->value = $value === 0;
		return true;
	}

	public function handleMenuClick(int $slot, Inventory $inventory): bool{
		$value = $this->value;
		$value = !$value;
		$this->setValue($value);

		if($value !== $this->getValue()){
			return false;
		}

		$item = $this->item;
		$this->setLore($item, $value);
		$inventory->setItem($slot, $item);
		return true;
	}

	private function setLore(Item $item, bool $value): void{
		if($value) {
			$item->setLore([
				"",
				C::RESET . C::BOLD . "» " . C::RESET.C::GRAY . $this->identifier . " enabled",
				C::RESET . C::GRAY . $this->identifier . " disabled"
			]);
		}else{
			$item->setLore([
				"",
				C::RESET . C::GRAY . $this->identifier . " enabled",
				C::RESET . C::WHITE . C::BOLD . "» " .C::RESET.C::GRAY . $this->identifier . " disabled"
			]);
		}
	}
}