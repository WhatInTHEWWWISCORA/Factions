<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\settings\setting\type;

use Ali\NetworkCore\libraries\invmenu\InvMenu;
use Ali\NetworkCore\libraries\pmforms\element\CustomFormElement;
use Closure;
use pocketmine\form\Form;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;

abstract class Setting{

	protected mixed $value;
	protected mixed $oldValue;

	private ?Closure $listener = null;

	public function __construct(protected string $identifier,protected string $name, protected Item $item, mixed &$value, private ?Closure $onOpen){
		$this->oldValue = $value;
		$this->value = &$value;
	}

	public function onOpen(): void{
		if($this->onOpen !== null){
			($this->onOpen)();
		}
	}

	public function getIdentifier():string{
		return $this->identifier;
	}

	public function getName():string{
		return $this->name;
	}

	/**
	 * @return Item
	 */
	public function getItem():Item{
		return $this->item;
	}

	public function getOldValue():mixed{
		return $this->oldValue;
	}

	/**
	 * @return mixed
	 */
	public function getValue():mixed{
		return $this->value;
	}

	public function setValue(mixed $value): void{
		$this->oldValue = $this->value;
		$this->value = $value;

		if($this->value !== $this->oldValue) {
			$this->onChanged();
		}
	}

	public function getButtonName(): string{
		return $this->name;
	}

	public function getCustomForm(): ?Form{
		return null;
	}

	public function getCustomMenu(?InvMenu $menu, ?Closure $closure): ?InvMenu{
		return null;
	}

	public abstract function isButtonSubmittable(): bool;

	/**
	 * @return CustomFormElement[]
	 */
	public abstract function getCustomFormComponents(): array;

	/**
	 * this will get called if the setting could be submitted when clicked
	 *
	 * @return bool
	 */
	public abstract function handleFormClick(): bool;

	/**
	 * Whenever the value of the setting is submitted
	 * function will get called
	 *
	 * @param mixed $value
	 * @return bool
	 */
	public abstract function handleFormResponse(int $key, mixed $value): bool;


	public abstract function handleMenuClick(int $slot, Inventory $inventory): bool;

	public function getChangeListener(): ?Closure{
		return $this->listener;
	}

	public function setChangeListener(Closure $listener): void{
		$this->listener = $listener;
	}

	public function onChanged(): void{
		if($this->listener !== null) {
			($this->listener)($this, $this->oldValue);
		}
	}



}