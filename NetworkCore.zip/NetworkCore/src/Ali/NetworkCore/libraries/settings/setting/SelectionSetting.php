<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\settings\setting;

use Ali\NetworkCore\libraries\invmenu\InvMenu;
use Ali\NetworkCore\libraries\invmenu\transaction\DeterministicInvMenuTransaction;
use Ali\NetworkCore\libraries\invmenu\type\InvMenuTypeIds;
use Ali\NetworkCore\libraries\pmforms\element\Dropdown;
use Ali\NetworkCore\libraries\settings\setting\type\Setting;
use Ali\NetworkCore\utils\world\SoundUtils;
use pocketmine\block\VanillaBlocks;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat as C;
use Closure;
use function array_flip;
use function array_keys;
use function count;
use function is_null;

class SelectionSetting extends Setting{

	/**
	 * @param string $identifier
	 * @param string[] $selections
	 * @param Item[] $items
	 * @param string $name
	 * @param Item $item
	 * @param mixed $value
	 */
	public function __construct(string $identifier,private array &$selections, private array &$items,string $name, Item $item, mixed &$value, ?Closure $onOpen = null){
		parent::__construct($identifier,$name, $item, $value, $onOpen);
		$item->setCustomName(C::RESET.$this->name);

		$keys = array_keys($this->selections);
		foreach($items as $key => $item) {
			if(!$item->hasCustomName()) {
				$item->setCustomName(C::RESET.$this->selections[$keys[$key]]);
			}
		}
		$this->updateItem();
	}

	private function updateItem(): void{

		if($this->value !== ""){
			if(!isset($this->selections[$this->value])){
				$this->value = "";
			}
		}

		$this->item->setLore([
			"",
			C::RESET.C::GOLD."Current".C::GRAY.": ".C::WHITE.($this->value === "" ? C::YELLOW."None" : $this->selections[$this->value])
		]);
	}

	public function isButtonSubmittable():bool{
		return false;
	}

	public function getCustomMenu(?InvMenu $menu, ?Closure $closure):?InvMenu{
		if(is_null($menu)){
			$menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
			$menu->setName($this->getName());
		}

		$items = $this->items;
		if($closure !== null) {
			$items[26] = VanillaBlocks::BARRIER()->asItem()->setCustomName(C::RESET . C::RED . "Back");
		}

		$menu->getInventory()->setContents($items);
		$menu->setListener(InvMenu::readonly(function(DeterministicInvMenuTransaction $transaction) use ($closure, $menu): void{
			$player = $transaction->getPlayer();
			$slot = $transaction->getAction()->getSlot();
			if($closure !== null) {
				if($slot === 26) {
					SoundUtils::click($player);
					$closure($player, $menu);
					return;
				}
			}

			if(!$transaction->getAction()->getInventory()->getItem($slot)->isNull()){
				if($this->handleFormResponse(0, $slot)){
					SoundUtils::enderMan($player);
				}else{
					SoundUtils::fail($player);
				}
				if($closure !== null) {
					$closure($player, $menu);
				}
				return;
			}

			SoundUtils::fail($player);
		}));

		return $menu;
	}

	public function getCustomFormComponents():array{
		$key = 0;
		if(count($this->selections) === 0) {
			return [];
		}

		return [new Dropdown($this->name, $this->name, $this->selections, $key)];
	}

	public function handleFormClick():bool{
		return true;
	}

	public function handleFormResponse(int $key, mixed $value):bool{
		$selection = array_keys($this->selections)[$value];
		$this->setValue($selection);

		$this->updateItem();
		return $this->getValue() === $selection;
	}

	public function handleMenuClick(int $slot, Inventory $inventory): bool{
		return false;
	}
}