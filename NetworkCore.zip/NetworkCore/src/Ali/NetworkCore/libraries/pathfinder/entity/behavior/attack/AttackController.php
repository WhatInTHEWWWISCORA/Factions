<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\entity\behavior\attack;

use Ali\NetworkCore\libraries\pathfinder\entity\behavior\Behaviour;
use Ali\NetworkCore\libraries\pathfinder\entity\behavior\NormalController;
use function array_rand;
use function count;
use function time;

class AttackController extends NormalController{

	private ?Behaviour $lastBehaviour = null;

	public function tick():void{

		if($this->lastBehaviour !== null) {
			if($this->lastBehaviour->isConditionsMet()) {
				$this->lastBehaviour->tick();
				return;
			}else{
				$coolDown = $this->lastBehaviour !== null ? $this->lastBehaviour->getCoolDown() : 0;
				$this->setCoolDown($coolDown - 2);
				$this->lastBehaviour = null;
			}
		}

		if($this->coolDown >= time()) {
			return;
		}

		$i = 0;
		$count = count($this->behaviours);

		do{
			$behaviour = $this->behaviours[array_rand($this->behaviours)];
			if(!$behaviour->isConditionsMet()) {
				$behaviour = $this->lastBehaviour;
			}

			if($i === $count){
				$behaviour = null;
				break;
			}
			$i++;
		}while($this->lastBehaviour === $behaviour && $count > 1);

		if($behaviour?->isConditionsMet()) {
			$this->lastBehaviour = $behaviour;
			$behaviour->tick();
		}
	}

}