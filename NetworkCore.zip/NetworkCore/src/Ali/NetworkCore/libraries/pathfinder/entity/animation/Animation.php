<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\entity\animation;
class Animation{

	public function __construct(string $name){

	}


}