<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\entity\behavior;

use function spl_object_hash;

abstract class Behaviour{

	protected array $controllers = [];

	public function addController(NormalController $controller): void{
		$this->controllers[spl_object_hash($controller)] = $controller;
	}

	protected function tickControllers(): void{
		foreach($this->controllers as $controller){
			$controller->tick();
		}
	}

	public abstract function tick(): void;

	public abstract function isConditionsMet(): bool;


}