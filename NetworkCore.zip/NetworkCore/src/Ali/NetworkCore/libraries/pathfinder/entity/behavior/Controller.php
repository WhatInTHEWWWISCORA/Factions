<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\entity\behavior;

interface Controller{

	public function setCoolDown(int $coolDown):void;

	public function tick():void;

	public function addBehaviour(Behaviour $children):void;

}