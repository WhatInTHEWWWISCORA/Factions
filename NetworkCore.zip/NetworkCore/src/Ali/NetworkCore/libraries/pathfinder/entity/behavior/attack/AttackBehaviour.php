<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\entity\behavior\attack;

use Ali\NetworkCore\libraries\pathfinder\entity\BaseEntity;
use Ali\NetworkCore\libraries\pathfinder\entity\behavior\Behaviour;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use function time;

class AttackBehaviour extends Behaviour{

	protected int $lastAttack = 0;

	public function __construct(protected BaseEntity $entity, protected int $distance, protected int $coolDown, protected int $globalCoolDown, protected float $damage){

	}

	public function tick():void{
		$target = $this->entity->getTargetEntity();
		$event = new EntityDamageByEntityEvent($this->entity, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage);
		$event->call();

		if(!$event->isCancelled()) {
			$target->attack($event);
			$this->lastAttack = time() + $this->coolDown;
		}

		foreach($this->controllers as $controller) {
			$controller->setCoolDown($this->coolDown);
		}
	}

	public function getCoolDown():int{
		return $this->globalCoolDown;
	}

	public function isConditionsMet():bool{
		$target = $this->entity->getTargetEntity();

		return (($this->lastAttack - time()) <= 0) && $this->entity->getPosition()->distance($target->getPosition()) <= $this->distance;
	}
}