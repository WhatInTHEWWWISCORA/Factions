<?php

declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\entity;

use Ali\NetworkCore\libraries\pathfinder\entity\behavior\Controller;
use Ali\NetworkCore\libraries\pathfinder\entity\behavior\NormalController;
use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;

abstract class BaseEntity extends Living {

	private bool $lockMovement = false;
	protected Controller $controller;

    public function __construct(Location $location, ?CompoundTag $nbt = null){
		$this->controller = new NormalController();
		parent::__construct($location, $nbt);
	}

	public function knockBack(float $x, float $z, float $force = 0.4, ?float $verticalLimit = 0.4):void{}

	public function isMovementLocked():bool{
		return $this->lockMovement;
	}

	public function setMovementLocked(bool $lockMovement):void{
		$this->lockMovement = $lockMovement;
	}

	public function getController():Controller{
		return $this->controller;
	}

    public function onUpdate(int $currentTick): bool{
		if($this->isFlaggedForDespawn() || $this->isClosed()){
			return parent::onUpdate($currentTick);
		}

		$this->controller->tick();
		parent::onUpdate($currentTick);

		return true;
    }
}