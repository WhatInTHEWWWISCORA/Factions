<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\entity\behavior;

use function spl_object_hash;

class NormalController implements Controller{

	/** @var Behaviour[] */
	protected array $behaviours = [];
	protected int $coolDown = 0;

	public function setCoolDown(int $coolDown): void{
		$this->coolDown = time() + $coolDown;
	}

	public function tick(): void{
		if($this->coolDown >= time()) {
			return;
		}

		foreach($this->behaviours as $child) {
			if($child->isConditionsMet()) {
				$child->tick();
			}
		}

	}

	public function addBehaviour(Behaviour $children): void{
		$this->behaviours[spl_object_hash($children)] = $children;
	}
}