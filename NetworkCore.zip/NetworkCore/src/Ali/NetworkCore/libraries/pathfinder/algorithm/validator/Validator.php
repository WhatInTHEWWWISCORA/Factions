<?php

declare(strict_types=1);

namespace Ali\NetworkCore\libraries\pathfinder\algorithm\validator;

use Ali\NetworkCore\libraries\pathfinder\algorithm\Algorithm;
use pocketmine\math\Vector3;

abstract class Validator {
    abstract public function isSafeToStandAt(Algorithm $algorithm, Vector3 $vector3): bool;
}