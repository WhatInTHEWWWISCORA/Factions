<?php

declare(strict_types=1);

namespace Ali\NetworkCore\libraries\invmenu\type;

use Ali\NetworkCore\libraries\invmenu\InvMenu;
use Ali\NetworkCore\libraries\invmenu\type\graphic\InvMenuGraphic;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

interface InvMenuType{

	public function createGraphic(InvMenu $menu, Player $player) : ?InvMenuGraphic;

	public function createInventory() : Inventory;
}