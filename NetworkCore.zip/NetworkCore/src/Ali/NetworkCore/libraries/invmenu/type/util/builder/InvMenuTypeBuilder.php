<?php

declare(strict_types=1);

namespace Ali\NetworkCore\libraries\invmenu\type\util\builder;

use Ali\NetworkCore\libraries\invmenu\type\InvMenuType;

interface InvMenuTypeBuilder{

	public function build() : InvMenuType;
}