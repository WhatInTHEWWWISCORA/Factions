<?php

declare(strict_types=1);

namespace Ali\NetworkCore\libraries\invmenu\type;

use Ali\NetworkCore\libraries\invmenu\inventory\InvMenuInventory;
use Ali\NetworkCore\libraries\invmenu\InvMenu;
use Ali\NetworkCore\libraries\invmenu\type\graphic\BlockInvMenuGraphic;
use Ali\NetworkCore\libraries\invmenu\type\graphic\InvMenuGraphic;
use Ali\NetworkCore\libraries\invmenu\type\graphic\network\InvMenuGraphicNetworkTranslator;
use Ali\NetworkCore\libraries\invmenu\type\util\InvMenuTypeHelper;
use pocketmine\block\Block;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

final class BlockFixedInvMenuType implements FixedInvMenuType{

	public function __construct(
		private Block $block,
		private int $size,
		private ?InvMenuGraphicNetworkTranslator $network_translator = null
	){}

	public function getSize() : int{
		return $this->size;
	}

	public function createGraphic(InvMenu $menu, Player $player) : ?InvMenuGraphic{
		$origin = $player->getPosition()->addVector(InvMenuTypeHelper::getPositionOffset())->floor();
		if(!InvMenuTypeHelper::isValidYCoordinate($origin->y)){
			return null;
		}

		return new BlockInvMenuGraphic($this->block, $origin, $this->network_translator);
	}

	public function createInventory() : Inventory{
		return new InvMenuInventory($this->size);
	}
}