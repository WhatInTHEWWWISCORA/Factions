<?php

declare(strict_types=1);

namespace Ali\NetworkCore\libraries\invmenu\session;

use Ali\NetworkCore\libraries\invmenu\InvMenu;
use Ali\NetworkCore\libraries\invmenu\type\graphic\InvMenuGraphic;

final class InvMenuInfo{

	public function __construct(
		public InvMenu $menu,
		public InvMenuGraphic $graphic,
		public ?string $graphic_name
	){}
}