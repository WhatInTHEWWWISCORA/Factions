<?php
declare(strict_types=1);

namespace Ali\NetworkCore\libraries\simplepackethandler;

use Ali\NetworkCore\libraries\simplepackethandler\interceptor\IPacketInterceptor;
use Ali\NetworkCore\NetworkCore;
use pocketmine\utils\SingletonTrait;

class BaseInterceptor{
	use SingletonTrait;

	private IPacketInterceptor $interceptor;

	public function __construct(NetworkCore $networkCore){
		self::setInstance($this);
		$this->interceptor = SimplePacketHandler::createInterceptor($networkCore);
	}

	public function getInterceptor(): IPacketInterceptor{
		return $this->interceptor;
	}

}