<?php /** @noinspection PhpUnused */
declare(strict_types=1);

namespace Ali\NetworkCore\handler;

use Ali\NetworkCore\CustomPlayer;
use Ali\NetworkCore\event\PlayerPreJoinEvent;
use Ali\NetworkCore\event\SpawnTeleportEvent;
use Ali\NetworkCore\features\DeathMessages;
use Ali\NetworkCore\features\PlaceBlackList;
use Ali\NetworkCore\network\CustomRakLibInterface;
use Ali\NetworkCore\player\OnlineSession;
use Ali\NetworkCore\player\SessionManager;
use Ali\NetworkCore\utils\player\DeviceUtils;
use Ali\NetworkCore\utils\player\PlayerUtils;
use Ali\NetworkCore\utils\player\ProfanityUtils;
use Ali\NetworkCore\utils\TimeUtils;
use Ali\NetworkCore\utils\world\BlockUtils;
use pocketmine\block\inventory\AnvilInventory;
use pocketmine\entity\object\ItemEntity;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\inventory\InventoryOpenEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\server\NetworkInterfaceRegisterEvent;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\GameRulesChangedPacket;
use pocketmine\network\mcpe\protocol\types\BoolGameRule;
use pocketmine\network\mcpe\raklib\RakLibInterface;
use pocketmine\network\query\DedicatedQueryNetworkInterface;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\TextFormat as C;
use raklib\RakLib;
use raklib\utils\InternetAddress;
use ReflectionObject;
use function explode;
use function implode;
use function is_null;
use function max;
use function min;
use function round;
use function strtolower;
use function time;
use function ucwords;

class PlayerHandler extends Handler{

	public function onPlayerCreate(PlayerCreationEvent $event): void{
		$event->setPlayerClass(CustomPlayer::class);
	}

	public function onQuery(QueryRegenerateEvent $event): void{
		if($this->plugin->getServer()->hasWhitelist()) {
			$whitelist = $this->plugin->getServer()->getWhitelisted();
			$event->getQueryInfo()->setExtraData(["AllowedPlayers" => implode("," , array_keys($whitelist->getAll()))]);
		}
	}

	public function onSpawn(EntitySpawnEvent $event): void{
		$entity = $event->getEntity();

		if($entity instanceof ItemEntity && $entity->getDespawnDelay() > 1200) {
			$entity->setDespawnDelay(1200);
		}
	}

	/**
	 * @priority MONITOR
	 */
	public function onDamage(EntityDamageEvent $event):void{
		if($event->getModifier(EntityDamageEvent::MODIFIER_PREVIOUS_DAMAGE_COOLDOWN) < 0.0){
			$event->cancel();
			return;
		}

		$victim = $event->getEntity();

		if($victim instanceof Player) {
			$session = $this->plugin->getSessionManager()->getSession($victim);

			$session->updateScoreTag($session->getPlayer()->getHealth() - $event->getFinalDamage());
		}
	}

	/**
	 * @priority LOWEST
	 */
	public function onMove(PlayerMoveEvent $event): void{
		$oldPosition = $event->getFrom();
		$newPosition = $event->getTo();

		$player = $event->getPlayer();
		if(!$player->hasBlockCollision()){
			return;
		}

		if($oldPosition->distance($newPosition) > 1.8) {
			$minX = min($oldPosition->x, $newPosition->x);
			$minY = min($oldPosition->y, $newPosition->y);
			$minZ = min($oldPosition->z, $newPosition->z);
			$maxX = max($oldPosition->x, $newPosition->x);
			$maxY = max($oldPosition->y, $newPosition->y);
			$maxZ = max($oldPosition->z, $newPosition->z);
			if(BlockUtils::containsBlock($event->getFrom()->getWorld(), new AxisAlignedBB($minX, $minY, $minZ, $maxX, $maxY, $maxZ))) {
				$event->cancel();
				return;
			}
		}


		$oldBlock = $player->getWorld()->getBlock(new Vector3($oldPosition->getFloorX(), (int) round($oldPosition->getY()), $oldPosition->getFloorZ()));
		$newBlock = $player->getWorld()->getBlock(new Vector3($newPosition->getFloorX(), (int) round($newPosition->getY()), $newPosition->getFloorZ()));
		if($oldBlock->getIdInfo()->getBlockId() !== $newBlock->getIdInfo()->getBlockId() && BlockUtils::isFullBlock($newBlock)) {
			$event->cancel();
		}
	}

	/**
	 * @priority MONITOR
	 */
	public function onRegen(EntityRegainHealthEvent $event):void{
		$victim = $event->getEntity();

		if($victim instanceof Player) {
			$session = $this->plugin->getSessionManager()->getSession($victim);

			if($session !== null) {
				$maxHealth = $session->getPlayer()->getMaxHealth();

				$session->updateScoreTag(min($session->getPlayer()->getHealth() + $event->getAmount(), $maxHealth));
			}
		}
	}

	public function onContainer(InventoryOpenEvent $event): void{
		if($event->getInventory() instanceof AnvilInventory){
			$event->cancel();
		}
	}

	public function onNetworkRegister(NetworkInterfaceRegisterEvent $event):void{
		$interface = $event->getInterface();

		if($interface instanceof RakLibInterface && !$interface instanceof CustomRakLibInterface) {
			$object = new ReflectionObject($interface);
			$property = $object->getProperty("rakLib");

			/** @var RakLib $raklib */
			$rakLib = $property->getValue($interface);
			$object = new ReflectionObject($rakLib);
			$property = $object->getProperty("address");

			/** @var InternetAddress $address */
			$address = $property->getValue($rakLib);

			$event->cancel();

			$server = $this->plugin->getServer();

			$server->getNetwork()->registerInterface(new CustomRakLibInterface($server, $server->getIp(), $address->getPort(), false));
			return;
		}

		if($interface instanceof DedicatedQueryNetworkInterface) {
			$event->cancel();
		}
	}

	public function onLoad(PlayerPreJoinEvent $event): void{
		$player = $event->getPlayer();
		$wg = $event->getWaitGroup();


		$wg->Add(2);
		$this->plugin->getPunishmentsManager()->checkForBan($player, function() use ($wg):void{
			$wg->Done();
		});

		$this->plugin->getSessionManager()->createSession($player, function(OnlineSession $session) use ($wg): void{
			$wg->Done();
			$this->plugin->getPunishmentsManager()->checkPlayerMute($session);
		});
	}

	public function onLogin(PlayerLoginEvent $event){
		$spawn = $this->plugin->getCoreConfig()->Spawn();

		if(!is_null($spawn) && $this->plugin->getCoreConfig()->AlwaysSpawn()) {
			$event = new SpawnTeleportEvent($event->getPlayer(), SpawnTeleportEvent::CAUSE_JOIN);
			$event->call();

			if(!$event->isCancelled()) {
				$event->getPlayer()->teleport($spawn);
			}
		}
	}

	/**
	 * @priority LOWEST
	 */
	public function PlayerJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		if(DeviceUtils::isProxy($player)) {
			$this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player):void{
				if(!$player->isConnected()) {
					return;
				}
				$player->kick("§fYou've ran into a problem, please open a ticket at §ddiscord.gg/Cora");
			}), 1);
		}

		$event->setJoinMessage("");
		$player->getNetworkSession()->sendDataPacket(GameRulesChangedPacket::create(["doimmediaterespawn" => new BoolGameRule(true, false)]));
		PlayerUtils::addPlayer($player);
	}

	public function onExhaust(PlayerExhaustEvent $event): void{
		$hunger = $event->getAmount();

		if($hunger > 0){
			$event->setAmount($hunger/2);
		}
	}

	/**
	 * @param BlockBreakEvent $event
	 * @return void
	 * @priority MONITOR
	 */
	public function onBreak(BlockBreakEvent $event): void{
		$drops = $event->getDrops();
		$player = $event->getPlayer();
		foreach($drops as $drop) {
			$sent = false;
			foreach($player->getInventory()->addItem($drop) as $item) {
				$player->getWorld()->dropItem($event->getBlock()->getPosition(), $item);
				if(!$sent){
					$player->sendPopup(C::RED."Your inventory is full".C::GRAY.".");
					$sent = true;
				}
			}
		}

		$event->setDrops([]);
	}

	public function onRespawn(PlayerRespawnEvent $event): void{
		$session = $this->plugin->getSessionManager()->getSession($event->getPlayer());
		$spawn = $this->plugin->getCoreConfig()->Spawn();

		if(!is_null($spawn)) {
			$ev = new SpawnTeleportEvent($event->getPlayer(), SpawnTeleportEvent::CAUSE_DEATH);
			$ev->call();

			if(!$ev->isCancelled()) {
				$event->setRespawnPosition($spawn);
			}
		}
		$session->updateScoreTag($event->getPlayer()->getMaxHealth());
	}

	public function onDeath(PlayerDeathEvent $event):void{
		$cause = $event->getEntity()->getLastDamageCause();

		$killer = null;
		if($cause instanceof EntityDamageByEntityEvent) {
			$killer = $cause->getDamager();
		}

		$event->setDeathMessage(DeathMessages::getInstance()->get(PlayerDeathEvent::deriveMessage($event->getPlayer()->getDisplayName(), $cause)->getText(), $event->getPlayer(), $killer));
	}

	public function onTeleport(EntityTeleportEvent $event):void{
		$player = $event->getEntity();

		if(!$player instanceof Player) {
			return;
		}

		$player->getNetworkSession()->sendDataPacket(GameRulesChangedPacket::create(["doimmediaterespawn" => new BoolGameRule(true, false)]));
	}

	/**
	 * @priority LOWEST
	 */
	public function onChat(PlayerChatEvent $event){
		$session = $this->plugin->getSessionManager()->getSession($event->getPlayer());
		if($session->getPlayer()->hasPermission("network.core")){
			return;
		}

		if(!$session->canTalk()) {
			if($session->isMuted()) {
				$session->getPlayer()->sendMessage(C::RED . "You are muted for " . TimeUtils::FormatTime($session->getMuteEntry()->getLength(), C::YELLOW, C::RED) . C::GRAY . ".");
			}
			$event->cancel();
			return;
		}

		if(ProfanityUtils::hasProfanity($event->getMessage())) {
			$event->getPlayer()->sendMessage(C::RED . "Please do not use bad words" . C::GRAY . ".");
			$event->cancel();
			return;
		}

		if($session->getLastMessage() === $event->getMessage()) {
			$event->getPlayer()->sendMessage(C::RED . "Do not repeat yourself" . C::GRAY . ".");
			$event->cancel();
			return;
		}

		$time = ($session->getLastMessageTime() + 3) - time();

		if($time > 0) {
			$event->getPlayer()->sendMessage(C::RED . "Please wait " . C::YELLOW . $time . C::RED . " seconds to send another message" . C::GRAY . ".");
			$event->cancel();
			return;
		}

		if(ProfanityUtils::countCapitals($event->getMessage()) > 15) {
			$event->setMessage(ucwords(strtolower($event->getMessage())));
		}

		$session->setLastMessage($event->getMessage());
		$session->setLastMessageTime(time());
	}

	/**
	 * @priority LOWEST
	 */
	public function onPlace(BlockPlaceEvent $event){
		if(PlaceBlackList::getInstance()->check($event->getItem())) {
			$event->cancel();
		}
	}

	public function onCommand(CommandEvent $event): void{
		$sender = $event->getSender();

		if($sender instanceof Player) {
			$session = SessionManager::get()->getSession($sender);
			$cmdParts = explode(" ", $event->getCommand());

			if($session->getPlayer()->hasPermission("network.core")) {
				$cmdParts[0] = strtolower($cmdParts[0]);
				$event->setCommand(implode(" ", $cmdParts));
				return;
			}


			$cmd = $this->plugin->getServer()->getCommandMap()->getCommand($cmdParts[0]);

			if($cmd !== null) {
				$time = $session->getLastCommandTime() - time();
				if($time > 0) {
					$sender->sendMessage(C::RED . "Please wait " . C::YELLOW . $time . C::RED . " seconds to execute another command" . C::GRAY . ".");
					$event->cancel();
					return;
				}
				$session->setLastCommandTime(time() + 2);
				return;
			}

			$cmdParts[0] = strtolower($cmdParts[0]);
			$event->setCommand(implode(" ", $cmdParts));
		}
	}

	/**
	 * @priority LOWEST
	 */
	public function onQuit(PlayerQuitEvent $event){
		PlayerUtils::removePlayer($event->getPlayer());
		$session = $this->plugin->getSessionManager()->getSession($event->getPlayer());
		if($session !== null) {
			$session->addOnlineTime(time() - $session->getLastLogin());
			$session->setLastLogin(time());
			$this->plugin->getSessionManager()->saveSession($session);
			$event->setQuitMessage("");
		}
	}

}