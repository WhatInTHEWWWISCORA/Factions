<?php
declare(strict_types=1);

namespace Ali\NetworkCore\handler;

use Ali\NetworkCore\NetworkCore;
use pocketmine\event\Listener;

class Handler implements Listener{
	public function __construct(protected NetworkCore $plugin){
	}

}