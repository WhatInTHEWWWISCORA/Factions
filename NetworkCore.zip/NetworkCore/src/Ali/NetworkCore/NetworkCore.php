<?php
declare(strict_types=1);

namespace Ali\NetworkCore;

use Ali\NetworkCore\commands\Commands;
use Ali\NetworkCore\features\Features;
use Ali\NetworkCore\handler\PlayerHandler;
use Ali\NetworkCore\libraries\invmenu\InvMenuHandler;
use Ali\NetworkCore\libraries\settings\Settings;
use Ali\NetworkCore\libraries\simplepackethandler\BaseInterceptor;
use Ali\NetworkCore\player\SessionManager;
use Ali\NetworkCore\provider\Provider;
use Ali\NetworkCore\provider\SQLProvider;
use Ali\NetworkCore\punishments\PunishmentsManager;
use Ali\NetworkCore\utils\item\ItemUtils;
use Ali\NetworkCore\utils\player\ProfanityUtils;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use function fclose;
use function file_get_contents;
use function json_decode;
use function mkdir;
use function preg_split;
use function stream_get_contents;

class NetworkCore extends PluginBase{
	use SingletonTrait;

	private CoreConfig $config;
	private Provider $provider;
	private SessionManager $sessionManager;
	private PunishmentsManager $punishmentsManager;
	private Features $features;

	protected function onLoad():void{
		$this->features = new Features($this);
	}

	public function onEnable():void{
		self::setInstance($this);
		new BaseInterceptor($this);
		$this->saveResource("bad_words.txt");
		$this->saveResource("deathMessages.yml");

		$data = $this->getResource("items.json");
		@mkdir($this->getDataFolder() . "data");
		ItemUtils::$textures = json_decode(stream_get_contents($data), true);
		fclose($data);
		ItemUtils::__init();

		ProfanityUtils::init(preg_split('/\r\n|\r|\n/',file_get_contents($this->getDataFolder()."bad_words.txt")));

		$this->config = new CoreConfig($this);
		$this->provider = new SQLProvider($this);
		$this->sessionManager = new SessionManager($this);
		$this->punishmentsManager = new PunishmentsManager($this);
		new Commands($this);


		InvMenuHandler::register($this);
		Settings::register($this);
		//TradeAPI::register($this);

		$this->getServer()->getPluginManager()->registerEvents(new PlayerHandler($this), $this);

		$enchantment = new Enchantment("",0,0,0,1);
		StringToEnchantmentParser::getInstance()->register("none", function() use ($enchantment):Enchantment{
			return $enchantment;
		});

		EnchantmentIdMap::getInstance()->register(-1,$enchantment);
		$this->features->enable();
	}

	public function getCoreConfig(): CoreConfig{
		return $this->config;
	}

	public function getProvider(): Provider{
		return $this->provider;
	}

	public function getSessionManager(): SessionManager{
		return $this->sessionManager;
	}

	public function getPunishmentsManager(): PunishmentsManager{
		return $this->punishmentsManager;
	}

	public function stopServer(): void{
		$fallbackServer = $this->getCoreConfig()->FallBackServer();
		if($fallbackServer["enabled"]) {
			$ip = $fallbackServer["ip"];
			$port = $fallbackServer["port"];

			foreach($this->getServer()->getOnlinePlayers() as $player) {
				$player->transfer($ip, (int) $port);
			}
		}
	}

	public function onDisable():void{
		$this->stopServer();
		$this->provider->close();
	}

}