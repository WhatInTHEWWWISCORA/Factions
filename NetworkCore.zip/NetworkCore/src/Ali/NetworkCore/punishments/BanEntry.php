<?php
declare(strict_types=1);

namespace Ali\NetworkCore\punishments;

use function time;

class BanEntry{

	const ID = "playerId";
	const EXECUTOR = "Executor";
	const REASON = "Reason";
	const EXPIRATION = "Expiration";
	const PERMANENT = "Permanent";

	private string $id, $executor, $reason;
	private int $expiration;
	private bool $permanent;

	public function __construct(array $data){
		$this->id = $data[self::ID];
		$this->executor = $data[self::EXECUTOR];
		$this->reason = $data[self::REASON];
		$this->expiration = $data[self::EXPIRATION];
		$this->permanent = $data[self::PERMANENT] === 1;
	}

	public function getId():string{
		return $this->id;
	}

	public function getExecutor():string{
		return $this->executor;
	}

	public function getReason():string{
		return $this->reason;
	}

	public function isActive():bool{
		return $this->expiration > time() || $this->permanent;
	}

	public function isPermanent():bool{
		return $this->permanent;
	}

	public function getLength():int{
		return $this->expiration - time();
	}
}