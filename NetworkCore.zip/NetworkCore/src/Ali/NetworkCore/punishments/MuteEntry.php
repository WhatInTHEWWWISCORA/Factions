<?php
declare(strict_types=1);

namespace Ali\NetworkCore\punishments;


use function time;

class MuteEntry{
	const ID = "playerId";
	const EXECUTOR = "Executor";
	const REASON = "Reason";
	const EXPIRATION = "Expiration";
	const PERMANENT = "Permanent";

	public static function create(string $id, string $executor, string $reason, int $expiration, bool $permanent): MuteEntry{
		return new MuteEntry(
			[
				self::ID => $id,
				self::EXECUTOR => $executor,
				self::REASON => $reason,
				self::EXPIRATION => $expiration,
				self::PERMANENT => $permanent
			]
		);
	}

	private string $id, $executor, $reason;
	private int $expiration;

	public function __construct(array $data){
		$this->id = $data[self::ID];
		$this->executor = $data[self::EXECUTOR];
		$this->reason = $data[self::REASON];
		$this->expiration = $data[self::EXPIRATION];
	}

	public function getId():string{
		return $this->id;
	}

	public function getExecutor():string{
		return $this->executor;
	}

	public function getReason():string{
		return $this->reason;
	}

	public function isActive():bool{
		return $this->expiration > time();
	}

	public function getLength():int{
		return $this->expiration - time();
	}
}