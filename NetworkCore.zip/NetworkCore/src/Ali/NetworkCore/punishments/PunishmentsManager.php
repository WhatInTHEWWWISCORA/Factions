<?php
declare(strict_types=1);

namespace Ali\NetworkCore\punishments;

use Ali\NetworkCore\libraries\DiscordWebhookAPI\Embed;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\OnlineSession;
use Ali\NetworkCore\player\SessionManager;
use Ali\NetworkCore\provider\Provider;
use Ali\NetworkCore\utils\TimeUtils;
use Closure;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;
use function strtolower;
use function time;

class PunishmentsManager{

	private Provider $provider;
	private bool $bannedAllowed;
	private array $permissions;

	public function __construct(NetworkCore $core){
		$this->provider = $core->getProvider();
		$this->bannedAllowed = $core->getCoreConfig()->BannedPlayersAllowed();

		$this->permissions = $core->getConfig()->get("Punishments", []);
	}

	public function canBan(CommandSender $sender, Closure $closure):void{
		if($sender instanceof ConsoleCommandSender) {
			$closure(true);
			return;
		}

		if($sender instanceof Player) {
			$session = SessionManager::get()->getSession($sender);
			$allowed = $this->getAllowedBans($session->getStaffRole());
			if($allowed === 0) {
				$closure(false);
				$sender->sendMessage(C::RED . "You cannot ban anyone" . C::GRAY . ".");
				return;
			}

			$this->getPlayerPunishments($sender->getUniqueId()->toString(), function(int $bansStart, int $bansCount, int $kicksStart, int $kicksCount) use ($session, $allowed, $closure):void{
				$player = $session->getPlayer();

				$coolDown = time() - $bansStart;
				$down = 5 * 60;
				if($coolDown <= $down) {
					if($bansCount >= $allowed) {
						if($player->isOnline()) {
							$player->sendMessage(C::RED . "You've reached your maximum bans, you can ban again in " . TimeUtils::FormatTime($down - $coolDown, C::DARK_RED . C::RED) . C::GRAY . ".");
							$closure(false);
							return;
						}
					}
					$bansCount++;
				}else{
					$bansStart = time();
					$bansCount = 1;
				}

				if($closure(true)) {
					$this->updatePlayerPunishments($player->getUniqueId()->toString(), $bansStart, $bansCount, $kicksStart, $kicksCount);
				}
			});
		}
	}

	public function canKick(CommandSender $sender, Closure $closure):void{
		if($sender instanceof ConsoleCommandSender) {
			$closure(true);
			return;
		}

		if($sender instanceof Player) {
			$session = SessionManager::get()->getSession($sender);
			$allowed = $this->getAllowedKicks($session->getStaffRole());
			if($allowed === 0) {
				$closure(false);
				$sender->sendMessage(C::RED . "You cannot ban anyone" . C::GRAY . ".");
				return;
			}

			$this->getPlayerPunishments($sender->getUniqueId()->toString(), function(int $bansStart, int $bansCount, int $kicksStart, int $kicksCount) use ($session, $allowed, $closure):void{
				$player = $session->getPlayer();

				$coolDown = time() - $kicksStart;
				$down = 5 * 60;
				if($coolDown <= $down) {
					if($kicksCount >= $allowed) {
						if($player->isOnline()) {
							$player->sendMessage(C::RED . "You've reached your maximum kicks, you can kick again in " . TimeUtils::FormatTime($down - $coolDown, C::DARK_RED . C::RED) . C::GRAY . ".");
							$closure(false);
							return;
						}
					}
					$kicksCount++;
				}else{
					$kicksStart = time();
					$kicksCount = 1;
				}

				if($closure(true)) {
					$this->updatePlayerPunishments($player->getUniqueId()->toString(), $bansStart, $bansCount, $kicksStart, $kicksCount);
				}
			});
		}
	}

	public function checkForBan(Player $player, ?Closure $isBanned = null):void{
		$this->isPlayerBanned($player->getUniqueId()->toString(), function(?BanEntry $banEntry) use ($player, $isBanned):void{
			if($player->isConnected() && $banEntry !== null) {
				if($banEntry->isActive()) {
					if($banEntry->isPermanent()) {
						$messages = C::RED . "\nYou are banned permanently\nReason" . C::GRAY . ": " . C::YELLOW . $banEntry->getReason();
					}else{
						$messages = C::RED . "\nYou are banned" . ($banEntry->getReason() !== "" ? "\nReason" . C::GRAY . ": " . C::YELLOW . $banEntry->getReason() : "") . C::RED . "\nExpires in " . TimeUtils::FormatTime($banEntry->getLength(), C::YELLOW, C::RED);
					}

					if($this->bannedAllowed) {
						$player->sendMessage($messages);
					}else{
						$player->kick($messages);
					}

					$isBanned($banEntry);
				}else{
					$isBanned($banEntry);
				}
			}else{
				$isBanned(null);
			}
		});
	}

	public function isPlayerBanned(string $id, Closure $closure):void{
		$this->provider->getPlayerBan($id, function(array $data) use ($closure):void{
			$data = $data[0] ?? [];
			if($data === []) {
				$closure(null);
				return;
			}
			$closure(new BanEntry($data));
		});
	}

	public function banPlayer(string $id, string $executor, string $reason, int $expiration, bool $permanent = false):void{
		$this->provider->banPlayer($id, $executor, $reason, $expiration, $permanent);
	}

	public function unbanPlayer(string $id):void{
		$this->provider->unbanPlayer($id);
	}

	public function checkPlayerMute(OnlineSession $session):void{
		$this->isPlayerMuted($session->getId(), function(array $data) use ($session):void{
			if($data === []) {
				$session->setMuteEntry(null);
				return;
			}

			$data = $data[0];
			$session->setMuteEntry(new MuteEntry($data));
		});
	}

	public function isPlayerMuted(string $id, Closure $closure):void{
		$this->provider->getPlayerMute($id, $closure);
	}

	public function mutePlayer(string $id, string $executor, string $reason, int $expiration):void{
		$this->provider->mutePlayer($id, $executor, $reason, $expiration);
	}

	public function unmutePlayer(string $id):void{
		$this->provider->unmutePlayer($id);
	}

	public function buildEmbed(string $type, string $executor, string $target, string $reason, int $expiration, bool $permanent):?Embed{
		$settings = NetworkCore::getInstance()->getCoreConfig();
		if($settings->DiscordAlerts()) {
			$embed = new Embed();
			$embed->setTitle($permanent ? "Permanent $type" : "Temporary $type");
			$embed->setAuthor($settings->DiscordTitle(), null, $settings->DiscordIcon());

			$embed->addField("Executor", $executor);
			$embed->addField("Target", $target);

			if($reason !== "") {
				$embed->addField("Reason", $reason);
			}

			if(!$permanent && $expiration !== -1) {
				$embed->addField("Length", TimeUtils::FormatTime($expiration - time()));
			}

			$embed->setColor($settings->DiscordColor());

			return $embed;
		}
		return null;
	}

	private function getPlayerPunishments(string $id, Closure $closure):void{
		$this->provider->getPunishments($id, function($data) use ($closure):void{
			if($data === []) {
				$closure(0, 0, 0, 0);
				return;
			}
			$data = $data[0];

			$closure($data["bansStart"], $data["bansCount"], $data["KicksStart"], $data["KicksCount"]);
		});
	}

	private function updatePlayerPunishments(string $id, int $bansStart, int $bansCount, int $kicksStart, int $kicksCount):void{
		$this->provider->savePunishments($id, $bansStart, $bansCount, $kicksStart, $kicksCount);
	}

	private function getAllowedBans(string $role):int{
		$allowed = $this->permissions[strtolower($role)] ?? [];

		return $allowed["bans"] ?? 0;
	}

	private function getAllowedKicks(string $role):int{
		$allowed = $this->permissions[strtolower($role)] ?? [];
		return $allowed["kick"] ?? 0;
	}
}