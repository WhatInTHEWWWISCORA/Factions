<?php
declare(strict_types=1);

namespace Ali\NetworkCore;

use pocketmine\item\Armor;
use pocketmine\item\Durable;
use pocketmine\player\Player;
use pocketmine\world\sound\ItemBreakSound;

class CustomPlayer extends Player{

	public function damageArmor(float $damage): void{
		$durabilityRemoved = (int) max(floor($damage / 4), 1);
		$armor = $this->armorInventory->getContents(true);
		foreach($armor as $slot => $item) {
			if($item instanceof Armor) {
				$this->damageItem($item, $durabilityRemoved);
				$this->armorInventory->setItem($slot, $item);
			}
		}
	}

	private function damageItem(Durable $item, int $durabilityRemoved) : void{
		$item->applyDamage($durabilityRemoved);
		if($item->isBroken()) {
			$this->broadcastSound(new ItemBreakSound());
		}
	}

}