<?php
declare(strict_types=1);

namespace Ali\NetworkCore\provider;

use Ali\NetworkCore\libraries\libasynql\DataConnector;
use Ali\NetworkCore\libraries\libasynql\libasynql;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\provider\mysql\SQLPlayer;
use Ali\NetworkCore\provider\mysql\SQLPunishment;
use Ali\NetworkCore\utils\data\Queries;

class SQLProvider extends Provider{
	use SQLPlayer;
	use SQLPunishment;

	protected DataConnector $dataConnector;

	public function __construct(NetworkCore $loader){
		$this->core = $loader;
		$this->init();
	}

	public function init():void{
		$this->dataConnector = libasynql::create($this->core, $this->core->getCoreConfig()->DataBaseSettings(), [
			"mysql" => [
				"mysql/player.sql",
				"mysql/punishment.sql"
			]
		]);

		$this->dataConnector->executeGeneric(Queries::INIT_PLAYERS);
		$this->dataConnector->executeGeneric(Queries::INIT_BANS);
		$this->dataConnector->executeGeneric(Queries::INIT_MUTES);
		$this->dataConnector->executeGeneric(Queries::INIT_PUNISHMENTS);
		$this->dataConnector->waitAll();

	}
	public function close():void{
		$this->dataConnector->waitAll();
		$this->dataConnector->close();
	}
}