<?php
declare(strict_types=1);

namespace Ali\NetworkCore\provider\mysql;

use Ali\NetworkCore\libraries\libasynql\DataConnector;
use Ali\NetworkCore\utils\data\Queries;
use Closure;

trait SQLPunishment{

	protected DataConnector $dataConnector;

	public function getPunishments(string $id, Closure $closure): void{
		$this->dataConnector->executeSelect(Queries::SELECT_PLAYER_PUNISHMENTS, [
			"id" => $id
		], $closure);
	}

	public function savePunishments(string $id, int $bansStart, int $bansCount, int $kicksStart, int $kicksCount): void{
		$this->dataConnector->executeInsert(Queries::INSERT_PUNISHMENTS, [
			"id" => $id,
			"bansStart" => $bansStart,
			"bansCount" => $bansCount,
			"KicksStart" => $kicksStart,
			"KicksCount" => $kicksCount,
		]);
	}

	public function getPlayerBan(string $id, Closure $closure):void{
		$this->dataConnector->executeSelect(Queries::SELECT_PLAYER_BAN, [
			"player" => $id], $closure);
	}

	public function banPlayer(string $id, string $executor, string $reason, int $expiration, bool $permanent = false):void{
		$this->dataConnector->executeInsert(Queries::INSERT_BAN, [
			"player" => $id,
			"executor" => $executor,
			"reason" => $reason,
			"expiration" => $expiration,
			"permanent" => $permanent ? 1 : 0,]);
	}

	public function unbanPlayer(string $id):void{
		$this->dataConnector->executeInsert(Queries::DELETE_BAN, [
			"player" => $id]);
	}

	public function getPlayerMute(string $id, Closure $closure):void{
		$this->dataConnector->executeSelect(Queries::SELECT_PLAYER_MUTE, [
			"player" => $id], $closure);
	}

	public function mutePlayer(string $id, string $executor, string $reason, int $expiration):void{
		$this->dataConnector->executeInsert(Queries::INSERT_MUTE, [
			"player" => $id,
			"executor" => $executor,
			"reason" => $reason,
			"expiration" => $expiration]);
	}

	public function unmutePlayer(string $id):void{
		$this->dataConnector->executeInsert(Queries::DELETE_MUTE, [
			"player" => $id]);
	}

}