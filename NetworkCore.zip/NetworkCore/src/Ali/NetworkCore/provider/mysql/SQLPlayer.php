<?php
declare(strict_types=1);

namespace Ali\NetworkCore\provider\mysql;

use Ali\NetworkCore\libraries\libasynql\DataConnector;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\utils\data\Queries;
use Closure;
use function json_encode;

trait SQLPlayer{

	protected NetworkCore $core;
	protected DataConnector $dataConnector;

	public function getPlayerId(string $name, Closure $closure): void{
		$this->dataConnector->executeSelect(Queries::SELECT_PLAYER_ID, [
			"name" => $name], $closure);
	}

	public function getPlayerIdByXuid(string $xuid, Closure $closure): void{
		$this->dataConnector->executeSelect(Queries::SELECT_PLAYER_XUID, [
			"xuid" => $xuid], $closure);
	}

	public function loadPlayerByName(string $username, Closure $closure):void{
		$this->dataConnector->executeSelect(Queries::SELECT_PLAYER_DATA_NAME, ["name" => $username], $closure);
	}

	public function loadPlayerById(string $id, Closure $closure):void{
		$this->dataConnector->executeSelect(Queries::SELECT_PLAYER_DATA_ID, ["id" => $id], $closure);
	}

	public function updatePlayerStatus(string $id):void{
		$this->dataConnector->executeInsert(Queries::UPDATE_PLAYER_STATUS, [
			"id" => $id,
			"server" => $this->core->getCoreConfig()->ServerName()]);
	}

	public function savePlayer(BaseSession $session, bool $online = false):void{
		$this->core->getLogger()->debug("Saving " . $session->getName() . " Data.");

		$this->dataConnector->executeInsert(Queries::INSERT_PLAYER, [
			"id" => $session->getId(),
			"name" => $session->getName(),
			"xuid" => $session->getXuid(),
			"online" => $online ? 1 : 0,
			"discordVerified" => $session->isDiscordVerified() ? 1 : 0,
			"discord" => $session->getDiscord(),
			"lastServer" => $this->core->getCoreConfig()->ServerName(),
			"lastLogin" => time(),
			"onlineTime" => json_encode($session->getOnlineTime()),
			"registration" => $session->getRegistrationDate(),
			"blocks" => json_encode($session->getBlocks())]);
	}

}