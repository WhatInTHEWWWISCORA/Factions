<?php
declare(strict_types=1);

namespace Ali\NetworkCore\provider;

use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Closure;

abstract class Provider{

	public abstract function __construct(NetworkCore $core);

	public abstract function init():void;

	public abstract function getPlayerId(string $name, Closure $closure):void;

	public abstract function getPlayerIdByXuid(string $xuid, Closure $closure):void;

	public abstract function loadPlayerByName(string $username, Closure $closure):void;

	public abstract function loadPlayerById(string $id, Closure $closure):void;

	public abstract function updatePlayerStatus(string $id):void;

	public abstract function savePlayer(BaseSession $session, bool $online = false):void;

	public abstract function getPlayerBan(string $id, Closure $closure):void;

	public abstract function banPlayer(string $id, string $executor, string $reason, int $expiration, bool $permanent = false):void;

	public abstract function unbanPlayer(string $id):void;

	public abstract function getPlayerMute(string $id, Closure $closure):void;

	public abstract function mutePlayer(string $id, string $executor, string $reason, int $expiration):void;

	public abstract function unmutePlayer(string $id):void;

	public abstract function getPunishments(string $id, Closure $closure):void;

	public abstract function savePunishments(string $id, int $bansStart, int $bansCount, int $kicksStart, int $kicksCount):void;

	public abstract function close():void;

}