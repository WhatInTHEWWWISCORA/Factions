<?php
declare(strict_types=1);

namespace Ali\NetworkCore\entity;

use pocketmine\entity\Location;
use pocketmine\entity\Zombie;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;

class FloatingTextEntity extends Zombie{

	public function __construct(Location $location){
		parent::__construct($location);
	}

	protected function initEntity(CompoundTag $nbt):void{
		parent::initEntity($nbt);
		$this->setScale(0.0001);
		$this->setNameTagAlwaysVisible();
		$this->setNameTagVisible();
	}


	public function attack(EntityDamageEvent $source):void{
	}

	protected function move(float $dx, float $dy, float $dz):void{}


	public function canSaveWithChunk():bool{
		return false;
	}

}