<?php
declare(strict_types=1);

namespace Ali\NetworkCore\entity;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\SetActorLinkPacket;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\types\entity\EntityLink;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\player\Player;
use pocketmine\Server;
use function mt_rand;

class Parrot extends Entity{

	const LEFT  = 0;
	const RIGHT = 1;
	const HEAD = 2;

	private ?SetActorLinkPacket $packet = null;
	private Player $player;

	public function __construct(Location $location, private int $shoulder){
		parent::__construct($location);
		$this->getNetworkProperties()->setGenericFlag(EntityMetadataFlags::DANCING, true);
		$this->getNetworkProperties()->setInt(EntityMetadataProperties::VARIANT, mt_rand(0, 4));
	}

	protected function entityBaseTick(int $tickDiff = 1):bool{
		if($this->player->isConnected()){
			$location = $this->player->getLocation();
			$currentPos = $this->location;

			if($currentPos->yaw !== $location->yaw || $currentPos->pitch !== $location->pitch) {
				$this->setPosition($location);
				$this->setRotation($location->yaw, $location->pitch);
			}
		}else{
			$this->flagForDespawn();
		}
		return parent::entityBaseTick($tickDiff);
	}

	protected function getInitialSizeInfo():EntitySizeInfo{
		return new EntitySizeInfo(0.5, 0.5);
	}

	public static function getNetworkTypeId():string{
		return EntityIds::PARROT;
	}

	protected function sendSpawnPacket(Player $player):void{
		parent::sendSpawnPacket($player);
		if($this->packet !== null) $player->getNetworkSession()->sendDataPacket($this->packet);
	}

	public function canSaveWithChunk():bool{
		return false;
	}

	public function sitOn(Player $player): void{
		$this->player = $player;
		if($this->shoulder === self::RIGHT){
			$vector = new Vector3(-0.39, -0.3, 0);
		}elseif($this->shoulder===self::HEAD){
			$vector = new Vector3(0,0,0);
		}elseif($this->shoulder === self::LEFT){
			$vector = new Vector3(0.39, -0.3, 0);
		}

		$this->packet = SetActorLinkPacket::create(new EntityLink($player->getId(), $this->getId(), EntityLink::TYPE_RIDER, true, true));
		$this->getNetworkProperties()->setVector3(EntityMetadataProperties::RIDER_SEAT_POSITION, $vector);
		Server::getInstance()->broadcastPackets($this->getViewers(), [$this->packet]);
	}
}