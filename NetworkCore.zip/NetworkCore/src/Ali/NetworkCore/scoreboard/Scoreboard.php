<?php
declare(strict_types=1);

namespace Ali\NetworkCore\scoreboard;

use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\player\Player;
use pocketmine\Server;
use function spl_object_hash;

class Scoreboard{

	private SetDisplayObjectivePacket $packet;

	/** @var ScoreboardEntry[] */
	protected array $entries = [];

	protected bool $hidden = false;

	public function __construct(private string $title, private array $viewers = []){
		$this->createPacket();
		$this->broadcastToViewers();
	}

	public function hide(): void{
		$this->removeFromViewers();
		$this->hidden = true;
	}

	public function show(): void{
		$this->hidden = false;
		$this->broadcastToViewers();
	}

	public function getViewers():array{
		return $this->viewers;
	}

	public function setViewers(array $viewers):void{
		$this->removeFromViewers();
		$this->viewers = $viewers;
		$this->broadcastToViewers();
	}

	public function addViewer(Player $player):void{
		$this->sendTo($player);
		$this->viewers[spl_object_hash($player)] = $player;
	}

	public function removeViewer(Player $player):void{
		if(isset($this->viewers[$id = spl_object_hash($player)])) {
			unset($this->viewers[$id]);
			$this->removeFrom($player);
		}
	}

	private function broadcastToViewers():void{
		if(!$this->hidden) {
			Server::getInstance()->broadcastPackets($this->viewers, [$this->packet]);
			foreach($this->entries as $entry){
				$entry->broadcastTo($this);
			}
		}
	}

	private function sendTo(Player $player):void{
		if($this->hidden){
			return;
		}
		$player->getNetworkSession()->sendDataPacket($this->packet);
		foreach($this->entries as $entry) {
			$entry->sendTo($player);
		}
	}

	private function removeFromViewers():void{
		$pk = new RemoveObjectivePacket();
		$pk->objectiveName = ScoreboardEntry::OBJECTIVE_NAME;

		Server::getInstance()->broadcastPackets($this->viewers, [$pk]);
	}


	private function removeFrom(Player $player):void{
		if($this->hidden){
			return;
		}
		$pk = new RemoveObjectivePacket();
		$pk->objectiveName = ScoreboardEntry::OBJECTIVE_NAME;

		$player->getNetworkSession()->sendDataPacket($pk);
	}

	private function createPacket():void{
		$this->packet = $pk = new SetDisplayObjectivePacket();
		$pk->displaySlot = SetDisplayObjectivePacket::DISPLAY_SLOT_SIDEBAR;
		$pk->displayName = $this->title;
		$pk->objectiveName = ScoreboardEntry::OBJECTIVE_NAME;
		$pk->criteriaName = "dummy";
		$pk->sortOrder = SetDisplayObjectivePacket::SORT_ORDER_ASCENDING;
	}

	public function getEntries():array{
		return $this->entries;
	}

	public function addEntry(ScoreboardEntry $entry):void{
		$this->entries[spl_object_hash($entry)] = $entry;
		$entry->__addScoreboard($this);
	}

	public function removeEntry(ScoreboardEntry $entry):void{
		unset($this->entries[spl_object_hash($entry)]);
		$entry->__removeScoreboard($this);
	}
}