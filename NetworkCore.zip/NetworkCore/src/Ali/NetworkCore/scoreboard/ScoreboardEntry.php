<?php
declare(strict_types=1);

namespace Ali\NetworkCore\scoreboard;

use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\player\Player;
use pocketmine\Server;
use function array_merge;
use function spl_object_hash;

class ScoreboardEntry{

	const OBJECTIVE_NAME = "scoreboard";

	private ScorePacketEntry $entry;
	private bool $enabled = true;

	public function __construct(private int $position, private string $value = "", private array $viewers = []){
		$this->createEntry();
		$this->broadcastToViewers();
	}

	public function isEnabled(): bool{
		return $this->enabled;
	}

	public function enable(): void{
		if(!$this->enabled) {
			$this->enabled = true;
			$this->broadcastToViewers();
		}
	}

	public function disable(): void{
		if($this->enabled){
			$this->enabled = false;
			$this->removeFromViewers();
		}
	}

	public function getPosition(): int{
		return $this->position;
	}

	public function setPosition(int $position):void{
		$this->removeFromViewers();
		$this->position = $position;
		$this->entry->score = $position;
		$this->entry->scoreboardId = $position;
		$this->broadcastToViewers();
	}

	public function getValue(): string{
		return $this->value;
	}

	public function setValue(string $value):void{
		$this->removeFromViewers();
		$this->value = $value;
		$this->entry->customName = $value;
		$this->broadcastToViewers();
	}

	/**
	 * @return Scoreboard[]
	 */
	public function getViewers():array{
		return $this->viewers;
	}

	public function removeAll():void{
		$this->removeFromViewers();
		$viewers = $this->viewers;
		$this->viewers = [];
		foreach($viewers as $viewer) {
			$viewer->removeEntry($this);
		}
	}

	/** @internal */
	public function __addScoreboard(Scoreboard $scoreboard):void{
		$this->viewers[spl_object_hash($scoreboard)] = $scoreboard;
		$this->broadcastTo($scoreboard);
	}

	/** @internal */
	public function __removeScoreboard(Scoreboard $scoreboard):void{
		$this->removeFrom($scoreboard);
		unset($this->viewers[spl_object_hash($scoreboard)]);
	}

	public function sendTo(Player $player):void{
		if(!$this->enabled){
			return;
		}
		$pk = new SetScorePacket();
		$pk->type = SetScorePacket::TYPE_CHANGE;
		$pk->entries = [$this->entry];

		$player->getNetworkSession()->sendDataPacket($pk);
	}

	public function broadcastTo(Scoreboard $scoreboard):void{
		if(!$this->enabled){
			return;
		}

		$pk = new SetScorePacket();
		$pk->type = SetScorePacket::TYPE_CHANGE;
		$pk->entries = [$this->entry];

		Server::getInstance()->broadcastPackets($scoreboard->getViewers(), [$pk]);
	}

	private function removeFrom(Scoreboard $scoreboard):void{
		if(!isset($this->viewers[spl_object_hash($scoreboard)])){
			return;
		}
		$pk = new SetScorePacket();
		$pk->type = SetScorePacket::TYPE_REMOVE;
		$pk->entries = [$this->entry];

		Server::getInstance()->broadcastPackets($scoreboard->getViewers(), [$pk]);
	}

	private function broadcastToViewers():void{
		if(!$this->enabled){
			return;
		}

		$pk = new SetScorePacket();
		$pk->type = SetScorePacket::TYPE_CHANGE;
		$pk->entries = [$this->entry];

		$viewers = [];
		foreach($this->viewers as $viewer) {
			$viewers = array_merge($viewers, $viewer->getViewers());
		}

		Server::getInstance()->broadcastPackets($viewers, [$pk]);
	}

	private function removeFromViewers():void{
		$pk = new SetScorePacket();
		$pk->type = SetScorePacket::TYPE_REMOVE;
		$pk->entries = [$this->entry];

		$viewers = [];
		foreach($this->viewers as $viewer) {
			$viewers = array_merge($viewers, $viewer->getViewers());
		}

		Server::getInstance()->broadcastPackets($viewers, [$pk]);
	}

	private function createEntry():void{
		$this->entry = $entry = new ScorePacketEntry();
		$entry->objectiveName = self::OBJECTIVE_NAME;
		$entry->type = ScorePacketEntry::TYPE_FAKE_PLAYER;
		$entry->customName = $this->value;
		$entry->score = $this->position;
		$entry->scoreboardId = $this->position;
	}

}