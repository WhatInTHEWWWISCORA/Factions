<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\world;

use pocketmine\player\Player;
use pocketmine\world\sound\ClickSound;
use pocketmine\world\sound\EndermanTeleportSound;
use pocketmine\world\sound\NoteInstrument;
use pocketmine\world\sound\NoteSound;
use pocketmine\world\sound\RedstonePowerOffSound;
use pocketmine\world\sound\XpLevelUpSound;

class SoundUtils{

	public static function click(Player $player):void{
		$player->getWorld()->addSound($player->getPosition(),new ClickSound(), [$player]);
	}

	public static function fail(Player $player):void{
		$player->getWorld()->addSound($player->getPosition(), new NoteSound(NoteInstrument::PIANO(), 4), [$player]);
	}

	public static function success(Player $player):void{
		$player->getWorld()->addSound($player->getPosition(),new XpLevelUpSound(10), [$player]);
	}

	public static function enderMan(Player $player):void{
		$player->getWorld()->addSound($player->getPosition(),new EndermanTeleportSound(), [$player]);
	}
}