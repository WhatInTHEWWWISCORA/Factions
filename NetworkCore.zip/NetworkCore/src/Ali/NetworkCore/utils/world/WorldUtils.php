<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\world;

use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\Position;
use pocketmine\world\World;
use function count;
use function explode;

class WorldUtils{

	public static function HashVector(Vector3 $vector):string{
		return $vector->getX() . ":" . $vector->getY() . ":" . $vector->getZ();
	}

	public static function HashPosition(Position $position):string{
		return self::HashVector($position) .":". $position->getWorld()->getFolderName();
	}

	public static function HashLocation(Location $location):string{
		return self::HashPosition($location) . ":" . $location->getYaw() . ":" . $location->getPitch();
	}

	public static function DisposeVector(string $hash): ?Vector3{
		$array = explode(":", $hash);

		switch($count = count($array)){
			case 3:
				return new Vector3((float) $array[0], (float) $array[1], (float) $array[2]);
			case 4:
			case 6:
				$world = self::getWorld($array[3]);
				if($world === null) {
					return null;
				}

				if($count === 4) {
					return new Position((float) $array[0], (float) $array[1], (float) $array[2], $world);
				}

				return new Location((float) $array[0], (float) $array[1], (float) $array[2], $world, (float) $array[4], (float) $array[5]);
			default:
				return null;
		}
	}

	public static function getWorld(string $world, bool $load = true):?World{
		$server = Server::getInstance();
		$worldObject = $server->getWorldManager()->getWorldByName($world);

		if($worldObject !== null) {
			return $worldObject;
		}

		if($load) {
			$server->getWorldManager()->loadWorld($world);
			return self::getWorld($world, false);
		}

		return null;
	}


}