<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\world;

use pocketmine\block\BaseSign;
use pocketmine\block\Block;
use pocketmine\block\BlockLegacyIds;
use pocketmine\block\Button;
use pocketmine\block\Chest;
use pocketmine\block\Crops;
use pocketmine\block\Door;
use pocketmine\block\EnderChest;
use pocketmine\block\FenceGate;
use pocketmine\block\Slab;
use pocketmine\block\Trapdoor;
use pocketmine\item\Bucket;
use pocketmine\item\FlintSteel;
use pocketmine\item\Hoe;
use pocketmine\item\Item;
use pocketmine\item\SpawnEgg;
use pocketmine\math\AxisAlignedBB;
use pocketmine\world\World;
use function floor;

class BlockUtils{

	private static array $interactive = [];

	public static function registerInteractiveItemBlock(Item $item): void{
		self::$interactive[$item->getId()] = true;
	}


	public static function isItemBlockInteractive(Item $item): bool{
		if($item instanceof Hoe){
			return true;
		}

		if($item instanceof Bucket){
			return true;
		}

		if($item instanceof FlintSteel){
			return true;
		}

		if($item instanceof SpawnEgg){
			return true;
		}

		return isset(self::$interactive[$item->getId()]);
	}


	public static function isInteractiveBlock(Block $block): bool{
		if($block instanceof Trapdoor){
			return true;
		}

		if($block instanceof Chest){
			return true;
		}

		if($block instanceof Door){
			return true;
		}

		if($block instanceof FenceGate){
			return true;
		}

		if($block instanceof EnderChest){
			return true;
		}

		return false;
	}

	const HALF_BLOCKS = [
		BlockLegacyIds::SAPLING => 1,
		BlockLegacyIds::SEAGRASS => 1,
		BlockLegacyIds::SEA_PICKLE => 1,
		BlockLegacyIds::MONSTER_SPAWNER => 1,
		BlockLegacyIds::COBWEB => 1,
		BlockLegacyIds::DEAD_BUSH => 1,
		BlockLegacyIds::TALLGRASS => 1,
		BlockLegacyIds::PISTON => 1,
		BlockLegacyIds::PISTONARMCOLLISION => 1,
		BlockLegacyIds::DANDELION => 1,
		BlockLegacyIds::POPPY => 1,
		BlockLegacyIds::CHORUS_FLOWER => 1,
		BlockLegacyIds::BROWN_MUSHROOM => 1,
		BlockLegacyIds::RED_MUSHROOM => 1,
		BlockLegacyIds::TORCH => 1,
		BlockLegacyIds::UNLIT_REDSTONE_TORCH => 1,
		BlockLegacyIds::REDSTONE_TORCH => 1,
		BlockLegacyIds::FIRE => 1,
		BlockLegacyIds::OAK_STAIRS => 1,
		BlockLegacyIds::COBBLESTONE_STAIRS => 1,
		BlockLegacyIds::BRICK_STAIRS => 1,
		BlockLegacyIds::STONE_BRICK_STAIRS => 1,
		BlockLegacyIds::NETHER_BRICK_STAIRS => 1,
		BlockLegacyIds::SPRUCE_STAIRS => 1,
		BlockLegacyIds::BIRCH_STAIRS => 1,
		BlockLegacyIds::JUNGLE_STAIRS => 1,
		BlockLegacyIds::QUARTZ_STAIRS => 1,
		BlockLegacyIds::ACACIA_STAIRS => 1,
		BlockLegacyIds::DARK_OAK_STAIRS => 1,
		BlockLegacyIds::RED_SANDSTONE_STAIRS => 1,
		BlockLegacyIds::PURPUR_STAIRS => 1,
		BlockLegacyIds::REDSTONE_WIRE => 1,
		BlockLegacyIds::REDSTONE_LAMP => 1,
		BlockLegacyIds::COMPARATOR_BLOCK => 1,
		BlockLegacyIds::POWERED_COMPARATOR => 1,
		BlockLegacyIds::UNPOWERED_REPEATER => 1,
		BlockLegacyIds::POWERED_REPEATER => 1,
		BlockLegacyIds::LEVER => 1,
		BlockLegacyIds::FARMLAND => 1,
		BlockLegacyIds::GRASS_PATH => 1,
		BlockLegacyIds::SIGN_POST => 1,
		BlockLegacyIds::WALL_SIGN => 1,
		BlockLegacyIds::WALL_BANNER => 1,
		BlockLegacyIds::STANDING_BANNER => 1,
		BlockLegacyIds::LADDER => 1,
		BlockLegacyIds::RAIL => 1,
		BlockLegacyIds::OAK_DOOR_BLOCK => 1,
		BlockLegacyIds::IRON_DOOR_BLOCK => 1,
		BlockLegacyIds::TRAPDOOR => 1,
		BlockLegacyIds::IRON_TRAPDOOR => 1,
		BlockLegacyIds::SPRUCE_DOOR_BLOCK => 1,
		BlockLegacyIds::BIRCH_DOOR_BLOCK => 1,
		BlockLegacyIds::JUNGLE_DOOR_BLOCK => 1,
		BlockLegacyIds::SPRUCE_TRAPDOOR => 1,
		BlockLegacyIds::ACACIA_DOOR_BLOCK => 1,
		BlockLegacyIds::DARK_OAK_DOOR_BLOCK => 1,
		BlockLegacyIds::HEAVY_WEIGHTED_PRESSURE_PLATE => 1,
		BlockLegacyIds::LIGHT_WEIGHTED_PRESSURE_PLATE => 1,
		BlockLegacyIds::STONE_PRESSURE_PLATE => 1,
		BlockLegacyIds::WOODEN_PRESSURE_PLATE => 1,
		BlockLegacyIds::SNOW_LAYER => 1,
		BlockLegacyIds::SUGARCANE_BLOCK => 1,
		BlockLegacyIds::FENCE => 1,
		BlockLegacyIds::FENCE_GATE => 1,
		BlockLegacyIds::NETHER_BRICK_FENCE => 1,
		BlockLegacyIds::SPRUCE_FENCE_GATE => 1,
		BlockLegacyIds::BIRCH_FENCE_GATE => 1,
		BlockLegacyIds::JUNGLE_FENCE_GATE => 1,
		BlockLegacyIds::DARK_OAK_FENCE_GATE => 1,
		BlockLegacyIds::ACACIA_FENCE_GATE => 1,
		BlockLegacyIds::STAINED_GLASS_PANE => 1,
		BlockLegacyIds::GLASS_PANE => 1,
		BlockLegacyIds::CAKE_BLOCK => 1,
		BlockLegacyIds::IRON_BARS => 1,
		BlockLegacyIds::PUMPKIN_STEM => 1,
		BlockLegacyIds::MELON_STEM => 1,
		BlockLegacyIds::VINES => 1,
		BlockLegacyIds::NETHER_WART_BLOCK => 1,
		BlockLegacyIds::NETHER_WART_PLANT => 1,
		BlockLegacyIds::BREWING_STAND_BLOCK => 1,
		BlockLegacyIds::CAULDRON_BLOCK => 1,
		BlockLegacyIds::END_PORTAL_FRAME => 1,
		BlockLegacyIds::PORTAL => 1,
		BlockLegacyIds::END_PORTAL => 1,
		BlockLegacyIds::COCOA => 1,
		BlockLegacyIds::ENDER_CHEST => 1,
		BlockLegacyIds::CHEST => 1,
		BlockLegacyIds::TRAPPED_CHEST => 1,
		BlockLegacyIds::TRIPWIRE => 1,
		BlockLegacyIds::TRIPWIRE_HOOK => 1,
		BlockLegacyIds::STONE_WALL => 1,
		BlockLegacyIds::FLOWER_POT_BLOCK => 1,
		BlockLegacyIds::CARROTS => 1,
		BlockLegacyIds::POTATOES => 1,
		BlockLegacyIds::SKULL_BLOCK => 1,
		BlockLegacyIds::ANVIL => 1,
		BlockLegacyIds::HOPPER_BLOCK => 1,
		BlockLegacyIds::ACTIVATOR_RAIL => 1,
		BlockLegacyIds::DETECTOR_RAIL => 1,
		BlockLegacyIds::GOLDEN_RAIL => 1,
		BlockLegacyIds::CARPET => 1,
		BlockLegacyIds::END_ROD => 1,
		BlockLegacyIds::ITEM_FRAME_BLOCK => 1,
		BlockLegacyIds::AIR => 1,
		BlockLegacyIds::ENCHANTING_TABLE => 1,
		BlockLegacyIds::DOUBLE_PLANT => 1,
		BlockLegacyIds::WATER => 1,
		BlockLegacyIds::WATER_LILY => 1,
		BlockLegacyIds::FLOWING_WATER => 1,
		BlockLegacyIds::LAVA => 1,
		BlockLegacyIds::FLOWING_LAVA => 1];

	public static function isFullBlock(Block $block):bool{
		if($block instanceof Slab && $block->isTransparent()){
			return false;
		}

		if($block instanceof Button || $block instanceof BaseSign || $block instanceof Crops){
			return false;
		}

		$id = $block->getIdInfo()->getBlockId();
		return !isset(self::HALF_BLOCKS[$id]);
	}

	public static function containsBlock(World $world , AxisAlignedBB $bb):bool{
		$minX = (int) floor($bb->minX);
		$minY = (int) floor($bb->minY);
		$minZ = (int) floor($bb->minZ);
		$maxX = (int) floor($bb->maxX);
		$maxY = (int) floor($bb->maxY);
		$maxZ = (int) floor($bb->maxZ);

		for($z = $minZ;$z <= $maxZ;++$z) {
			for($x = $minX;$x <= $maxX;++$x) {
				for($y = $minY;$y <= $maxY;++$y) {
					$block = $world->getBlockAt($x, $y, $z);
					if(self::isFullBlock($block)) {
						return true;
					}
				}
			}
		}

		return false;
	}


}