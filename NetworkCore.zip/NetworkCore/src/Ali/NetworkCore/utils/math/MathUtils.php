<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\math;

use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\world\format\Chunk;
use function abs;
use function array_keys;
use function array_map;
use function array_reduce;
use function floatval;
use function mt_rand;
use function number_format;
use function pow;
use function shuffle;

class MathUtils{

	public static function getChunkCoordinate(int $coordinate): int{
		return $coordinate >> Chunk::COORD_BIT_SIZE;
	}

	public static function middle(Vector3 $vector3):Vector3{
		$x = $vector3->getX();
		$z = $vector3->getZ();

		return $vector3->add($x > 0 ? 0.5 : -0.5, 0.0, $z > 0 ? -0.5 : 0.5);
	}

	public static function getDirection(float $deg):int{
		$deg = fmod($deg, 360);
		if($deg < 0) {
			$deg += 360;
		}

		if(45 >= $deg) {
			return Facing::SOUTH;
		}

		if(135 >= $deg) {
			return Facing::WEST;
		}

		if(225 >= $deg) {
			return Facing::NORTH;
		}

		if(315 >= $deg) {
			return Facing::EAST;
		}

		return Facing::SOUTH;
	}

	public static function numberShorten(float|int $number, int $precision = 2, array $divisors = null):string{
		if(!isset($divisors)) {
			$divisors = [
				pow(1000, 0) => '',
				pow(1000, 1) => 'K',
				pow(1000, 2) => 'M',
				pow(1000, 3) => 'B',
				pow(1000, 4) => 'T',
				pow(1000, 5) => 'Qa',
				pow(1000, 6) => 'Qi',];
		}

		foreach($divisors as $divisor => $shorthand) {
			if(abs($number) < ($divisor * 1000)) {
				break;
			}
		}

		return floatval(number_format($number / ($divisor ?? 1), $precision)) . ($shorthand ?? "");
	}

	public static function convertToRoman(int $num): string{
		$res = '';
		$romanNumber_Array = [
			'M' => 1000,
			'CM' => 900,
			'D' => 500,
			'CD' => 400,
			'C' => 100,
			'XC' => 90,
			'L' => 50,
			'XL' => 40,
			'X' => 10,
			'IX' => 9,
			'V' => 5,
			'IV' => 4,
			'I' => 1];
		foreach($romanNumber_Array as $roman => $number) {
			$matches = intval($num / $number);
			$res .= str_repeat($roman, $matches);
			$num = $num % $number;
		}
		return $res;
	}

	public static function Chance(float $chance): bool{
		return self::weightedChoice([
				["chance" => $chance],
				["chance" => 100 - $chance]]) === 0;
	}

	public static function weightedChoice(array $weightPairs): mixed{
		$weightPairs = array_map(static function($key, array $thing):array{
			return [$key, $thing["chance"] ?? 0];
		}, array_keys($weightPairs), $weightPairs);
		shuffle($weightPairs);

		if($weightPairs === []) {
			return 0;
		}

		$multiplier = 1000000;

		$total = array_reduce($weightPairs, function($sum, $v){
			return $sum + $v[1];
		});

		$totalMultiplayer = $total * $multiplier;
		if($totalMultiplayer === 0){
			$totalMultiplayer = 1;
		}

		$r = mt_rand(1, (int) $totalMultiplayer);

		$acc = 0;
		foreach($weightPairs as $pair) {
			$acc += $pair[1] * $multiplier;
			if($acc >= $r) {
				return $pair[0];
			}
		}

		return $pair[0] ?? 0;
	}

}