<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\item;

use Ali\NetworkCore\utils\math\MathUtils;
use Exception;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\utils\TextFormat as C;
use function array_merge;
use function count;
use function is_null;
use function strtolower;

class ItemUtils{

	private const ORIGINAL_LORE = "original_lore";

	public static array $textures = [];
	private static array $items = [];

	public static function __init():void{
		foreach(VanillaBlocks::getAll() as $key => $block) {
			$item = $block->getPickedItem();
			self::$items[$item->getId()][$item->getMeta()] = strtolower($key);
		}

		foreach(VanillaItems::getAll() as $key => $item) {
			self::$items[$item->getId()][$item->getMeta()] = strtolower($key);
		}
	}

	public static function getItemTexture(Item $item):string{
		$name = self::$items[$item->getId()][$item->getMeta()];
		return "https://minecraftitemids.com/item/128/" . $name . ".png";
	}

	public static function getOriginalLore(Item $item):array{
		$lore = [];

		$tag = $item->getNamedTag()->getListTag(self::ORIGINAL_LORE);
		if($tag !== null) {
			/** @var StringTag $t */
			foreach($tag as $t) {
				$lore[] = $t->getValue();
			}
		}else{
			self::saveOriginalLore($item);
			return $item->getLore();
		}

		return $lore;
	}

	public static function saveOriginalLore(Item $item):void{
		$lore = $item->getLore();

		$loreTag = new ListTag();
		foreach($lore as $line) {
			$loreTag->push(new StringTag($line));
		}
		$item->getNamedTag()->setTag(self::ORIGINAL_LORE, $loreTag);
	}

	public static function setLore(Item $item, array $lore):void{
		$item->setLore($lore);
		self::saveOriginalLore($item);
		self::applyMetaLore($item, false);
	}

	public static function addLore(Item $item, array $lore, bool $end = true):void{
		$originalLore = self::getOriginalLore($item);

		if($end) {
			$originalLore = array_merge($originalLore, $lore);
		}else{
			$originalLore = array_merge($lore, $originalLore);
		}
		$item->setLore($originalLore);
		self::saveOriginalLore($item);
		self::applyMetaLore($item, false);
	}

	public static function addTemporaryLore(Item $item, array $lore, bool $end = true):void{
		$originalLore = self::getOriginalLore($item);

		if($end) {
			$originalLore = array_merge($originalLore, $lore);
		}else{
			$originalLore = array_merge($lore, $originalLore);
		}
		$item->setLore($originalLore);

		self::applyMetaLore($item, false);
	}

	public static function applyMetaLore(Item $item, bool $load = true):void{
		$ItemRarity = $item->getNamedTag()->getTag("rarity");

		if($load) {
			$originalLore = self::getOriginalLore($item);
		}else{
			$originalLore = $item->getLore();
		}

		if($ItemRarity !== null) {
			$lore = [
				C::RESET . C::GRAY . "Rarity: " . Rarities::toString($ItemRarity->getValue()),
			];
		}else{
			$lore = [];
		}

		$enchantments = [""];
		$enchantmentMap = EnchantmentIdMap::getInstance();

		foreach($item->getEnchantments() as $enchantment) {
			try{
				$id = $enchantmentMap->toId($enchantment->getType());
			}catch(Exception){
				continue;
			}

			if($id >= 100) {
				$rarity = $enchantment->getType()->getRarity();
				$enchantments[] = C::RESET . Rarities::getRarityColor($rarity) . $enchantment->getType()->getName() . " " . MathUtils::convertToRoman($enchantment->getLevel());
			}
		}


		if(count($enchantments) > 1) {
			$lore = array_merge($enchantments, $lore);
		}

		if($originalLore !== []) {
			$lore[] = "";
		}

		$lore = array_merge($lore, $originalLore);
		$item->setLore($lore);
	}

}