<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\item;

use pocketmine\item\Item;
use pocketmine\utils\TextFormat as C;

class Rarities{

	const COMMON = 1;
	const UNCOMMON = 2;
	const RARE = 3;
	const EPIC = 4;
	const LEGENDARY = 5;
	const MYTHIC = 6;
	const DIVINE = 7;
	const SPECIAL = 8;
	const VERY_SPECIAL = 9;

	public static function toString(int $rarity): string{
		return match ($rarity){
			default => C::WHITE."Common",
			self::UNCOMMON => C::GREEN."Uncommon",
			self::RARE => C::BLUE . "Rare",
			self::EPIC => C::DARK_RED . "Epic",
			self::LEGENDARY => C::GOLD . "Legendary",
			self::MYTHIC => C::RED . "Mythic",
			self::DIVINE => C::AQUA . "Divine",
			self::SPECIAL => C::RED . "Special",
			self::VERY_SPECIAL => C::RED . "Very Special",
		};
	}

	public static function getRarityColor(int $rarity):string{
		return match ($rarity) {
			default => C::WHITE,
			self::UNCOMMON => C::GREEN,
			self::RARE => C::BLUE,
			self::EPIC => C::DARK_RED,
			self::LEGENDARY => C::GOLD,
			self::MYTHIC => C::RED,
			self::DIVINE => C::AQUA,
			self::SPECIAL, self::VERY_SPECIAL => C::RED
		};
	}

	public static function applyRarity(Item $item, int $rarity):void{
		$item->getNamedTag()->setInt("rarity", $rarity);
		ItemUtils::applyMetaLore($item);
	}

}