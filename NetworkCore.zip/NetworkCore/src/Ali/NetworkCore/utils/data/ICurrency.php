<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

use Closure;

interface ICurrency{

	public function getBalance(): float;

	public function getName(): string;

	public function addListener(Closure $closure):string;

	public function setListener(string $name, Closure $closure):void;

	public function removeListener(string $hash):void;

	public function getSymbol(): string;

}