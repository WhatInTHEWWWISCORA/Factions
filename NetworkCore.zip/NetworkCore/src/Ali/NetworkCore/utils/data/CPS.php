<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

use function array_filter;
use function count;
use function microtime;

class CPS extends Currency{

	private array $cps = [];

	private float $lastBalance = 0;
	private float $lastUpdate = 0;

	public function addBalance(float $amount):float{
		$this->cps[] = microtime(true);

		$this->onUpdate(0);
		return 0;
	}

	public function reduceBalance(float $amount):float{
		return 0;
	}

	public function setBalance(float $amount):void{
	}

	public function getBalance():float{
		$now = microtime(true);
		if($this->lastUpdate !== $now) {
			$this->lastUpdate = $now;
			$time = $now;
			$this->lastBalance = count(array_filter($this->cps, static function(float $t) use ($time):bool{
				return ($time - $t) <= 1;
			}));
		}

		return $this->lastBalance;
	}

	public function getLastBalance(): float{
		return $this->lastBalance;
	}

}