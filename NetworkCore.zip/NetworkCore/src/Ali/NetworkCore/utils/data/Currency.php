<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

use function abs;

class Currency implements ICurrency{
	use ListenerTrait;

	private bool $limited;

	public function __construct(private float $value, private string $name, private string $symbol,private int $maxValue = -1){
		$this->maxValue = abs($this->maxValue);
		$this->limited = $maxValue > 1;
	}

	public function getBalance(): float{
		return $this->value;
	}

	public function setBalance(float $amount): void{
		$oldAmount = $this->value;

		if($this->limited && $amount > $this->maxValue){
			$this->value = $this->maxValue;
			$this->onUpdate($oldAmount);
			return;
		}

		if($amount < 0){
			$this->value = 0;
			$this->onUpdate($oldAmount);
			return;
		}

		$this->value = $amount;
		$this->onUpdate($oldAmount);
	}

	public function addBalance(float $amount): float{
		if($amount < 0){
			return 0;
		}

		$oldAmount = $this->value;
		$nextAmount = $amount + $this->value;

		if($this->limited) {
			if($this->maxValue < $nextAmount) {
				$this->value = $this->maxValue;
				$this->onUpdate($oldAmount);
				return $nextAmount - $this->maxValue;
			}
		}

		$this->value = $nextAmount;
		$this->onUpdate($oldAmount);
		return 0;
	}

	public function reduceBalance(float $amount): float{
		if($amount < 0){
			return 0;
		}

		$oldAmount = $this->value;
		$nextAmount = $this->value - $amount;

		if($nextAmount < 0){
			$this->value = 0;
			$this->onUpdate($oldAmount);
			return abs($nextAmount);
		}

		$this->value = $nextAmount;
		$this->onUpdate($oldAmount);
		return 0;
	}

	public function getName(): string{
		return $this->name;
	}

	public function getSymbol(): string{
		return $this->symbol;
	}
}