<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

class Queries{

	const INIT_PLAYERS = "core.init-players";
	const INIT_MUTES = "core.init-mutes";
	const INIT_BANS = "core.init-bans";
	const INIT_PUNISHMENTS = "core.init-punishments-cooldown";

	const INSERT_PLAYER = "core.save-player";
	const INSERT_MUTE = "core.mute-player";
	const INSERT_BAN = "core.ban-player";
	const INSERT_PUNISHMENTS = "core.punishments-insert-player-cooldown";

	const UPDATE_PLAYER_STATUS = "core.update-online-status";

	const SELECT_PLAYER_ID = "core.get-player-id";
	const SELECT_PLAYER_XUID = "core.get-player-xuid";
	const SELECT_PLAYER_DATA_ID = "core.load-player-id";
	const SELECT_PLAYER_DATA_NAME = "core.load-player-name";
	const SELECT_PLAYER_BAN = "core.get-player-ban";
	const SELECT_PLAYER_MUTE = "core.get-player-mute";
	const SELECT_PLAYER_PUNISHMENTS = "core.select-player-cooldown";

	const DELETE_BAN = "core.unban-player";
	const DELETE_MUTE = "core.unmute-player";

}