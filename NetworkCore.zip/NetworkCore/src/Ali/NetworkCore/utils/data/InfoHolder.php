<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

use function array_unshift;

class InfoHolder{

	/** @var InfoEntry[] */
	private array $entries = [];

	public function push(InfoEntry $entry): void{
		array_unshift($this->entries, $entry);
	}

	public function add(InfoEntry $entry): void{
		$this->entries[] = $entry;
	}

	public function get(): array{
		$data = [];

		foreach($this->entries as $entry){
			$data += $entry->get();
		}

		return $data;
	}

}