<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

use function spl_object_hash;
use Closure;

trait ListenerTrait{
	/** @var Closure[] */
	private array $listeners = [];

	public function addListener(Closure $closure):string{
		$this->listeners[$hash = spl_object_hash($closure)] = $closure;
		return $hash;
	}

	public function setListener(string $name, Closure $closure):void{
		$this->listeners[$name] = $closure;
	}

	public function removeListener(string $hash):void{
		unset($this->listeners[$hash]);
	}

	protected function onUpdate(...$data):void{
		foreach($this->listeners as $listener) {
			$listener($this, ...$data);
		}
	}
}