<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

use Closure;
use function is_null;

/**
 * Basic wait group implementation
 */
class WaitGroup{

	private int $required = 0;
	private int $done = 0;

	private ?Closure $action = null;

	public function __construct() {

	}

	public function Add(int $amount = 1): void{
		$this->required += $amount;
	}

	public function Done(): void{
		$this->done++;
		$this->execute();
	}

	public function then(Closure $closure): void{
		$this->action = $closure;
		$this->execute();
	}

	private function execute(): void{
		if(is_null($this->action)){
			return;
		}

		if($this->required === $this->done){
			($this->action)();
			$this->action = null;
		}
	}

}