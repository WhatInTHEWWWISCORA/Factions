<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\data;

abstract class InfoEntry{

	public abstract function get(): array;

}