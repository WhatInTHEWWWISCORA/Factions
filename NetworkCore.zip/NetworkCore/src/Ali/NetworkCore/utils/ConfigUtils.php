<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils;

use Ali\NetworkCore\utils\item\ItemUtils;
use Ali\NetworkCore\utils\item\Rarities;
use Ali\NetworkCore\utils\player\Reward;
use Ali\NetworkCore\utils\player\type\CommandReward;
use Ali\NetworkCore\utils\player\type\ItemReward;
use Exception;
use pocketmine\block\Block;
use pocketmine\data\bedrock\EffectIdMap;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\StringToEffectParser;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\StringToItemParser;
use pocketmine\utils\TextFormat;
use function chr;
use function explode;
use function getimagesize;
use function imagecolorat;
use function imagecreatefrompng;
use function imagedestroy;
use function is_array;
use function is_null;
use function is_numeric;
use function str_contains;
use function strtolower;

class ConfigUtils{

	public static function getImageData(string $path):string{
		$bytes = '';
		$data = @getimagesize($path);
		if(is_array($data)) {
			$l = (int) $data[1];
			$w = (int) $data[0];
			$img = @imagecreatefrompng($path);
			if($img !== false) {
				for($y = 0;$y < $l;$y++) {
					for($x = 0;$x < $w;$x++) {
						$rgba = @imagecolorat($img, $x, $y);
						$a = ((~($rgba >> 24)) << 1) & 0xff;
						$r = ($rgba >> 16) & 0xff;
						$g = ($rgba >> 8) & 0xff;
						$b = $rgba & 0xff;
						$bytes .= chr($r) . chr($g) . chr($b) . chr($a);
					}
				}
				@imagedestroy($img);
			}
		}
		return $bytes;
	}

	/**
	 * @param Reward[] $rewards
	 * @return array
	 */
	public static function processRewards(array $rewards): array{
		$result = [];
		foreach($rewards as $reward) {
			$type = $reward["type"] ?? "";
			switch(strtolower($type)){
				case "cmd":
				case "command":
					$command = $reward["command"] ?? "";
					if($command !== "") {
						$result[] = new CommandReward($command, $reward["name"] ?? "", $reward["item"] ?? "");
					}
					break;
				case "item":
					try{
						$item = self::loadItem($reward);
						$result[] = new ItemReward($item);
					}catch(Exception){
					}
					break;
			}
		}

		return $result;
	}

	public static function saveItem(Item $Item): array{
		$id = $Item->getId().":".$Item->getMeta().":".$Item->getCount().($Item->hasCustomName() ? ":".$Item->getCustomName() : "");

		$enchantments = [];

		foreach($Item->getEnchantments() as $enchantment){
			$enchantments[] = [
				"id" => EnchantmentIdMap::getInstance()->toId($enchantment->getType()),
				"level" => $enchantment->getLevel()];
		}

		return [
			"id" => $id,
			"enchantments" => $enchantments];
	}

	/**
	 * @throws Exception
	 */
	public static function loadItem(array $item): Item{
		$id = $item["id"] ?? "";
		$enchantments = $item["enchantments"] ?? null;
		$lore = $item["lore"] ?? [];
		$rarity = $item["rarity"] ?? -1;

		if($id === ""){
			$id = $item["item"] ?? "";
		}

		$item = self::processItem($id);

		if($item === null){
			throw new Exception("unknown id.");
		}


		ItemUtils::setLore($item, $lore);

		if(is_array($enchantments)) {
			$enchantments = self::processEnchantments($enchantments);

			foreach($enchantments as $eKey => $enchantment) {
				if(is_null($enchantment)) {
					throw new Exception("Couldn't load Enchantment with key ($eKey) unknown id.");
				}

				$item->addEnchantment($enchantment);
			}
		}

		if($rarity !== -1) {
			Rarities::applyRarity($item, $rarity);
		}
		return $item;
	}

	public static function processBlock(string $block): ?Block{
		$item = self::processItem($block);

		return $item?->getBlock();
	}

	public static function processItem(string $item): ?Item{
		$itemData = explode(":", $item);

		$id = $itemData[0] ?? null;
		$meta = $itemData[1] ?? 0;
		$count = $itemData[2] ?? 1;
		$customName = $itemData[3] ?? null;
		if(is_null($id)){
			return null;
		}

		if(is_numeric($id)) {
			$item = ItemFactory::getInstance()->get((int) $id,(int) $meta);
		}else{
			$item = StringToItemParser::getInstance()->parse($id);
		}

		if(is_null($item)) {
			return null;
		}

		$item->setCount((int) $count);

		if($customName !== null) {
			if(!str_contains("§",$customName)){
				$customName = TextFormat::RESET.TextFormat::WHITE.$customName;
			}
			$item->setCustomName($customName);
		}

		return $item;
	}

	/**
	 * @param array $enchantments
	 * @return EnchantmentInstance[]
	 */
	public static function processEnchantments(array $enchantments): array{
		$result = [];
		foreach($enchantments as $enchantment) {
			$id = $enchantment["id"] ?? null;

			if(is_null($id)) {
				$result[] = null;
				continue;
			}

			if(is_numeric($id)) {
				$enchantmentResult = EnchantmentIdMap::getInstance()->fromId((int) $id);
			}else{
				$enchantmentResult = StringToEnchantmentParser::getInstance()->parse($id);
			}

			/**
			 * @var Enchantment $enchantment
			 */
			if(is_null($enchantment)){
				$result[] = null;
				continue;
			}
			$level = $enchantment["id"] ?? 1;

			$result[] = new EnchantmentInstance($enchantmentResult,$level);
		}

		return $result;
	}

	public static function processEffect(array $effect): ?EffectInstance{
		$id = $effect["id"] ?? null;
		$level = $effect["level"] ?? 1;
		$visible = $effect["visible"] ?? true;
		$duration = $effect["duration"] ?? 1;

		if(is_null($id)){
			return null;
		}

		if(is_numeric($id)){
			$effect = EffectIdMap::getInstance()->fromId((int) $id);
		}else{
			$effect = StringToEffectParser::getInstance()->parse((string) $id);
		}

		if(is_null($effect)){
			return null;
		}

		return new EffectInstance($effect,(int) $duration * 20,(int) $level-1,$visible);
	}

	public static function saveEffect(EffectInstance $effectInstance): array{
		$id = EffectIdMap::getInstance()->toId($effectInstance->getType());
		$duration = $effectInstance->getDuration();
		$level = $effectInstance->getAmplifier() + 1;
		$visible = $effectInstance->isVisible();

		return [
			"id" => $id,
			"duration" => $duration,
			"level" => $level,
			"visible" => $visible];
	}
}