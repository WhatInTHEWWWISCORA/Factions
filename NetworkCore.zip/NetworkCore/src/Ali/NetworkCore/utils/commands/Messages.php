<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\commands;

use Ali\NetworkCore\utils\TimeUtils;
use pocketmine\utils\TextFormat as C;
use function count;
use function strtolower;

class Messages{

	public static function PlayerNotFound(string $name):string{
		return C::RED . "Player with the name " . C::YELLOW . strtolower($name) . C::RED . " wasn't found.";
	}

	public static function PlayerBanned(string $name, int $length = 0):string{
		return C::GREEN . "$name has been banned" . ($length !== 0 ? " for " . TimeUtils::FormatTime($length, C::YELLOW, C::RED) : "") . ".";
	}

	public static function PlayerMuted(string $name, int $length):string{
		return C::YELLOW . "$name" . C::GREEN . " has been muted for " . TimeUtils::FormatTime($length, C::YELLOW, C::GREEN) . ".";
	}

	public static function PlayerUnMuted(string $name):string{
		return C::YELLOW . "$name" . C::GREEN . " has been un-muted.";
	}

	public static function Muted(string $reason, int $length):string{
		return C::RED . "You have been muted for " . TimeUtils::FormatTime($length, C::YELLOW, C::RED) . ($reason !== "" ? ", Reason: " . C::YELLOW . $reason : "") . C::RED . ".";
	}

	public static function UnMuted():string{
		return C::GREEN . "You have been un-muted.";
	}

	public static function AlreadyBlocked(): string{
		return C::RED."Player is already blocked".C::GRAY.".";
	}

	public static function Blocked(): string{
		return C::GREEN."Player has been blocked".C::GRAY.".";
	}

	public static function NotBlocked(): string{
		return C::RED."Player isn't blocked".C::GRAY.".";
	}

	public static function UnBlocked(): string{
		return C::GREEN."Player has been unblocked".C::GRAY.".";
	}

	public static function BlockedFromMessages(string $player): string{
		return C::RED."You are blocked from sending ".C::YELLOW.$player.C::RED." private messages".C::GRAY.".";
	}

	public static function PrivateMessage(string $player, string $to, string $message): string{
		return C::GRAY . "[$player -> $to: " .C::WHITE. $message.C::GRAY."]";
	}

	public static function DiscordVerified(): string{
		return C::RED."Your discord is already connected to your account".C::GRAY.".";
	}

	public static function DiscordCode(string $code): string{
		return C::GREEN."Your discord verification code is ".C::YELLOW.$code.C::GRAY.".";
	}

	public static function formatArray(array $array): string{
		$message = "";
		$len = count($array);
		$i = 0;
		foreach($array as $key => $value){
			$i++;
			$message .= C::RED."$key".C::GRAY.": ".C::WHITE.$value;
			if($i < $len){
				$message .= "\n";
			}
		}

		return $message;
	}
}