<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\player\type;

use Ali\NetworkCore\utils\ConfigUtils;
use Ali\NetworkCore\utils\player\Reward;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use function is_null;
use function str_replace;

class CommandReward extends Reward{

	private Item $item;

	public function __construct(private string $command, private string $name, string $item){
		$item = ConfigUtils::processItem($item);
		if(is_null($item)) {
			$item = VanillaItems::PAPER();
		}

		$this->item = $item;
		$item->setCustomName($this->name === "" ? $this->command : $this->name);
	}

	public function getCommand():string{
		return $this->command;
	}

	public function getName():string{
		return $this->name;
	}

	public function getDisplayItem():Item{
		return clone $this->item;
	}

	public function setCommand(string $command):void{
		$this->command = $command;
	}

	public function reward(Player $player):void{
		$this->rewardHolder($player->getName());
	}

	public function rewardHolder(string $name):void{
		$sender = new ConsoleCommandSender(Server::getInstance(), Server::getInstance()->getLanguage());
		Server::getInstance()->dispatchCommand($sender, str_replace("{player}", "\"" . $name . "\"", $this->command));
	}

}