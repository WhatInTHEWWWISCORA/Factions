<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\player\type;

use Ali\NetworkCore\utils\player\Reward;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;

class ItemReward extends Reward{

	public function __construct(private Item $item){}

	public function getItem():Item{
		return clone $this->item;
	}

	public function reward(Player $player, bool $dropItem = true):void{
		if(!$dropItem) {
			$item = $this->getItem();
			if($player->getInventory()->canAddItem($item)){
				$player->getInventory()->addItem($item);
			}else{
				$player->sendPopup(C::RED."Your inventory is full".C::GRAY.".");
			}
			return;
		}
		foreach($player->getInventory()->addItem($this->getItem()) as $drop) {
			$player->getWorld()->dropItem($player->getPosition(), $drop);
		}
	}
}