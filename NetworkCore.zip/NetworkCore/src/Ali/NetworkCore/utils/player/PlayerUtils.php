<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\player;

use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat as C;
use function is_null;
use function strtolower;

class PlayerUtils{

	private static array $namesMap = [];
	private static array $idMap = [];

	public static function addPlayer(Player $player):void{
		self::$idMap[$player->getId()] = $player;
		self::$namesMap[strtolower($player->getName())] = $player;
	}

	public static function removePlayer(Player $player):void{
		unset(self::$idMap[$player->getId()]);
		unset(self::$namesMap[strtolower($player->getName())]);
	}

	public static function getPlayer(string $name):?Player{
		$p = self::$namesMap[strtolower($name)] ?? null;

		if(is_null($p)) {
			$p = Server::getInstance()->getPlayerByPrefix($name);

			if(is_null($p) || !isset(self::$idMap[$p->getId()])) {
				return null;
			}
		}

		return $p;
	}

	public static function getPlayerById(int $id):?Player{
		return self::$idMap[$id] ?? null;
	}

	public static function getPingColor(int $ping):string{
		if($ping <= 120) {
			return C::GREEN;
		}

		if($ping <= 250) {
			return C::YELLOW;
		}

		return C::DARK_RED;
	}
}