<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\player;

use function array_keys;
use function array_values;
use function count;
use function implode;
use function preg_match;
use function preg_quote;
use function preg_replace;
use function str_replace;
use function str_split;

class ProfanityUtils{

	const SEPARATOR_PLACEHOLDER = '{!!}';
	private const ESCAPED_SEPARATOR_CHARACTERS = [
		'\s'
	];

	const SEPARATOR_CHARACTERS = '@#%&_;\'",~`|!$^*()-+={}[]:<>?./';
	const CHARACTER_SUBSTITUTIONS = [
		"/a/" => "a4@ÁáÀÂàÂâÄäÃãÅåæÆαΔΛλ",
		"/b/" => "b8\\3ßΒβ",
		"/c/" => "cÇçćĆčČ¢€<({©",
		"/d/" => "d\)ÞþÐð",
		"/e/" => "e3€ÈèÉéÊêëËēĒėĖęĘ∑",
		"/f/" => "fƒ",
		"/g/" => "g69",
		"/h/" => "hΗ",
		"/i/" => "i!|][1∫ÌÍÎÏìíîïīĪįĮ",
		"/j/" => "j",
		"/k/" => "kΚκ",
		"/l/" => "l!|][£∫ÌÍÎÏłŁ",
		"/m/" => "m",
		"/n/" => "nηΝΠñÑńŃ",
		"/o/" => "o0ΟοΦ¤°øôÔöÖòÒóÓœŒøØōŌõÕ",
		"/p/" => "pρΡ¶þ",
		"/q/" => "q",
		"/r/" => "r®",
		"/s/" => "s5\$§ßŚśŠš",
		"/t/" => "tΤτ",
		"/u/" => "uυµûüùúūÛÜÙÚŪ",
		"/v/" => "vυν",
		"/w/" => "wωψΨ",
		"/x/" => "xΧχ",
		"/y/" => "y¥γÿýŸÝ",
		"/z/" => "zΖžŽźŹżŻ",
	];

	private static array $profanities = [];
	private static string $separatorExpression;
	private static array $characterExpressions;

	public static function init(array $profanities = []):void{
		self::$profanities = $profanities;
		self::$separatorExpression = self::generateEscapedExpression(str_split(self::SEPARATOR_CHARACTERS), self::ESCAPED_SEPARATOR_CHARACTERS);
		self::$characterExpressions = self::generateCharacterExpressions();

		$profanities = [];
		$profanityCount = count(self::$profanities);
		for($i = 0;$i < $profanityCount;$i++) {
			$profanities[$i] = self::generateProfanityExpression(self::$profanities[$i], self::$characterExpressions, self::$separatorExpression);
		}

		self::$profanities = $profanities;
	}

	public static function countCapitals(string $text):int{
		return mb_strlen(preg_replace('![^A-Z]+!', '', $text));
	}

	public static function hasProfanity(string $string):bool{
		if($string === "") {
			return false;
		}

		foreach(self::$profanities as $profanity) {
			if(preg_match($profanity, $string) === 1) {
				return true;
			}
		}
		return false;
	}

	private static function generateEscapedExpression(array $characters = [], array $escapedCharacters = [], string $quantifier = '*?'):string{
		$regex = $escapedCharacters;
		foreach($characters as $character) {
			$regex[] = preg_quote($character, '/');
		}
		return '[' . implode('', $regex) . ']' . $quantifier;
	}

	private static function generateCharacterExpressions():array{
		$characterExpressions = [];
		foreach(self::CHARACTER_SUBSTITUTIONS as $character => $substitutions) {
			$characterExpressions[$character] = ProfanityUtils::generateEscapedExpression(str_split($substitutions), [], '+?');
		}
		return $characterExpressions;
	}

	private static function generateProfanityExpression(string $word, array $characterExpressions, string $separatorExpression):string{
		return str_replace(self::SEPARATOR_PLACEHOLDER, $separatorExpression, '/' . preg_replace(array_keys($characterExpressions), array_values($characterExpressions), $word) . '/i');
	}
}