<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\player;

use Ali\NetworkCore\utils\ConfigUtils;
use Ali\NetworkCore\utils\player\type\CommandReward;
use Ali\NetworkCore\utils\player\type\ItemReward;
use pocketmine\player\Player;

abstract class Reward{

	public abstract function reward(Player $player): void;

	public static function fromArray(array $data): ?Reward{
		$type = $data["type"] ?? null;

		if($type === null){
			return null;
		}

		$type = strtolower($type);

		if($type === "item"){
			try{
				$item = ConfigUtils::loadItem($data);
			}catch(\Exception){
				return null;
			}


			$reward = new ItemReward($item);
		}else{
			$reward = new CommandReward($data["command"] ?? "", $data["name"] ?? "", $data["item"] ?? "");
		}

		return $reward;
	}

}