<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils\player;

use pocketmine\network\mcpe\protocol\types\DeviceOS;
use pocketmine\player\Player;
use function array_flip;
use function str_contains;
use function str_replace;
use function strtolower;
use function ucfirst;

class DeviceUtils{

	private static array $devicesNames = [];

	private static function generateNames(): void{
		$reflect = new \ReflectionClass(DeviceOS::class);
		$constants = $reflect->getConstants();

		self::$devicesNames = array_flip($constants);
	}

	public static function getDeviceName(int $type): string{
		if(self::$devicesNames === []){
			self::generateNames();
		}

		return ucfirst(str_replace("_", " ",strtolower(self::$devicesNames[$type] ?? self::$devicesNames[-1])));
	}


	public static function isMobile(Player $player): bool{
		$mobile = $player->getPlayerInfo()->getExtraData()["DeviceOS"];

		return $mobile === DeviceOS::ANDROID || $mobile === DeviceOS::IOS;
	}

	public static function isProxy(Player $player): bool{
		$deviceModel = $player->getPlayerInfo()->getExtraData()["DeviceModel"];
		if(str_contains(strtolower($deviceModel), "unknown")){
			return true;
		}

		return false;
	}

}