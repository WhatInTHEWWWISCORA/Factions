<?php
declare(strict_types=1);

namespace Ali\NetworkCore\utils;

use function floor;
use function is_numeric;
use function str_split;

class TimeUtils{

	private const UNITS = [
		"year",
		"month",
		"day",
		"hour",
		"minute",
		"second"
	];

	private const SHORT_UNITS = [
		"y",
		"m",
		"d",
		"h",
		"m",
		"s"
	];

	public static function ProcessTime(int $time): array{
		$minute = 60;
		$hour = $minute * 60;
		$day = $hour * 24;
		$month = $day * 30;
		$year = $month * 12;

		$years = (int) floor($time / $year);
		$time -= $years * $year;

		$months = (int) floor($time / $month);
		$time -= $months * $month;

		$days = (int) floor($time / $day);
		$time -= $days * $day;

		$hours = (int) floor($time / $hour);
		$time -= $hours * $hour;

		$minutes = (int) floor($time / $minute);
		$time -= $minutes * $minute;

		$seconds = (int) floor($time);

		return [
			$years,
			$months,
			$days,
			$hours,
			$minutes,
			$seconds
		];
	}

	public static function FormatTimeClockStyle(int $time, string $timeColor = "", string $separatorColor = ""): string{
		$array = self::ProcessTime($time);
		$result = "";

		$i = 0;
		foreach($array as $time) {
			if($time > 0 || $i > 0) {
				$i++;
				$result .= ($i > 1 ? $separatorColor . ":" : "") . $timeColor . ($time >= 10 ? $time : "0" . $time);
			}
		}

		return $result;
	}

	public static function FormatTime(int $time, string $timeColor = "", string $unitColor = "", bool $short = false, int $precision = -1):string{
		$array = self::ProcessTime($time);
		$result = "";

		$i = 0;
		foreach($array as $unit => $time) {
			if($time > 0) {
				$i++;
				if($short) {
					$result .= ($i > 1 ? " " : "") . $timeColor . $time  . $unitColor . self::SHORT_UNITS[$unit];
				}else{
					$result .= ($i > 1 ? " " : "") . $timeColor . $time . " " . $unitColor . self::UNITS[$unit] . ($time > 1 ? "s" : "");
				}

				if($precision !== -1){
					if($precision === ($i-1)){
						break;
					}
				}
			}
		}

		return $result;
	}

	public static function parseTime(string $string):?int{
		if($string === "") {
			return null;
		}

		$time = 0;
		$unit = "";
		$array = str_split($string);
		foreach($array as $value) {
			if(is_numeric($value)){
				$unit .= $value;
				continue;
			}

			$v = match ($value) {
				"y" => 24 * 60 * 60 * 30 * 12,
				"w" => 24 * 60 * 60 * 7,
				"d" => 24 * 60 * 60,
				"h" => 60 * 60,
				"m" => 60,
				"s" => 1,
				default => 0,
			};

			if($v !== 0) {
				$v *= (int) $unit;
				$time += $v;
				$unit = "";
			}
		}

		$time += (int) $unit;

		return $time;
	}

}