<?php
declare(strict_types=1);

namespace Ali\NetworkCore\player;

use Ali\NetworkCore\libraries\settings\SettingsHolder;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\parts\ModifiableTrait;
use Ali\NetworkCore\punishments\BanEntry;
use Ali\NetworkCore\punishments\MuteEntry;
use Ali\NetworkCore\utils\data\CPS;
use Ali\NetworkCore\utils\data\Currency;
use Ali\NetworkCore\utils\player\PlayerUtils;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;
use function time;

class OnlineSession extends BaseSession{
	use ModifiableTrait;

	private Player $player;

	private ?MuteEntry $entry = null;
	private ?BanEntry $banEntry = null;

	private bool $canTalk = false;
	private Currency $ping;
	private CPS $cps;

	private string $LastMessage = "";
	private int $lastMessageTime = 0;
	private int $lastCommandTime = 0;

	private string $staffRole = "";
	private string $lastSender = "";
	private ?SettingsHolder $settings = null;

	public function __construct(Player $player){
		parent::__construct();
		$this->player = $player;
		$this->setLastLogin(time());

		$this->ping = new Currency(0, "ping", "");
		$this->ping->addListener(function(Currency $currency, float $oldBalance):void{
			if($currency->getBalance() === $oldBalance) {
				return;
			}

			$this->updateScoreTag($this->player->getHealth());
		});
		$this->cps = new CPS(0, "", "");
		$this->cps->addListener(function(CPS $cps):void{
			if(!$this->player->isConnected()){
				return;
			}
			$this->player->sendTip(C::RED . $cps->getBalance());
		});
	}

	public function getCps():CPS{
		return $this->cps;
	}

	public function updateScoreTag(float $health): void{
		$this->player->setScoreTag(round($health, 2) . C::RED . "HP " . C::GREEN . PlayerUtils::getPingColor((int) $this->ping->getBalance()) . $this->ping->getBalance() . C::WHITE . "MS");
	}

	protected function ready():void{
		$player = $this->getPlayer();
		$this->setLastLogin(time());
		if($this->name === "") {
			$this->name = $player->getName();
			$this->xuid = $player->getXuid();
			$this->id = $player->getUniqueId()->toString();
		}
	}

	public function getPlayer():Player{
		return $this->player;
	}

	public function getOnlineTime(): array{
		$data = parent::getOnlineTime();
		$time = $data[$name = NetworkCore::getInstance()->getCoreConfig()->ServerName()] ?? 0;
		$data[$name] = $time + (time() - $this->getLastLogin());
		return $data;
	}

	public function getMuteEntry(): ?MuteEntry{
		return $this->entry;
	}

	public function setMuteEntry(?MuteEntry $entry): void{
		$this->entry = $entry;
		$this->canTalk = true;
	}

	public function isMuted(): bool{
		return $this->entry !== null && $this->entry->isActive();
	}

	public function getBanEntry(): ?BanEntry{
		return $this->banEntry;
	}

	public function setBanEntry(?BanEntry $entry): void{
		$this->banEntry = $entry;
	}

	public function isBanned(): bool{
		return $this->banEntry !== null && $this->banEntry->isActive();
	}

	public function canTalk(): bool{
		return $this->canTalk && !$this->isMuted();
	}

	public function getPing():Currency{
		return $this->ping;
	}

	public function setLastMessage(string $LastMessage):void{
		$this->LastMessage = $LastMessage;
	}

	public function getLastMessage():string{
		return $this->LastMessage;
	}

	public function setLastMessageTime(int $lastMessageTime):void{
		$this->lastMessageTime = $lastMessageTime;
	}

	public function getLastMessageTime():int{
		return $this->lastMessageTime;
	}

	public function getLastCommandTime():int{
		return $this->lastCommandTime;
	}

	public function setLastCommandTime(int $lastCommandTime):void{
		$this->lastCommandTime = $lastCommandTime;
	}

	public function getStaffRole():string{
		return $this->staffRole;
	}

	public function setStaffRole(string $staffRole):void{
		$this->staffRole = $staffRole;
	}

	public function getLastSender():string{
		return $this->lastSender;
	}

	public function setLastSender(string $lastSender):void{
		$this->lastSender = $lastSender;
	}

	public function getSettings():?SettingsHolder{
		return $this->settings;
	}

	public function setSettings(?SettingsHolder $settings):void{
		$this->settings = $settings;
	}

}