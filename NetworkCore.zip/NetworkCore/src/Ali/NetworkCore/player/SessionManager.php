<?php
declare(strict_types=1);

namespace Ali\NetworkCore\player;

use Ali\NetworkCore\event\SessionCreationEvent;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\provider\Provider;
use Ali\NetworkCore\utils\player\PlayerUtils;
use pocketmine\player\Player;
use Closure;
use function time;

class SessionManager{

	private static self $instance;

	private array $onlineSessions = [];

	private Provider $provider;
	private NetworkCore $loader;

	public function __construct(NetworkCore $loader){
		self::$instance = $this;
		$this->loader = $loader;
		$this->provider = $loader->getProvider();
	}

	public static function get():self{
		return self::$instance;
	}

	public function createSession(Player $player, Closure $onLoad): void{
		$session = new OnlineSession($player);
		$name = $player->getName();
		$id = $player->getUniqueId()->toString();
		$this->provider->loadPlayerById($id, function(array $data) use ($session, $name, $onLoad):void{
			$data[0][BaseSession::LAST_SERVER] = $this->loader->getCoreConfig()->ServerName();
			$this->loader->getLogger()->debug("Online " . $name . " has been loaded");
			$session->__setData($data);

			if($session->getRegistrationDate() === time()) {
				$this->provider->savePlayer($session, true);
			}else{
				$this->provider->updatePlayerStatus($session->getId());
			}

			$this->onlineSessions[$session->getId()] = $session;
			if(!$session->getPlayer()->isConnected()) {
				$this->saveSession($session);
			}else{
				$event = new SessionCreationEvent($session);
				$event->call();

				$event->getWaitGroup()->then(function() use ($onLoad, $session): void{
					if(!$session->getPlayer()->isConnected()) {
						$this->saveSession($session);
					}else{
						$onLoad($session);
					}
				});
			}});
	}

	public function getSession(Player $player): ?OnlineSession{
		$id = $player->getUniqueId()->toString();
		if(isset($this->onlineSessions[$id])) {
			return $this->onlineSessions[$id];
		}

		return null;
	}

	//this is only used to read data, you can't modify data.
	public function getOfflineSession(string $id, Closure $onLoad): void{
		$session = new BaseSession();
		$this->provider->loadPlayerById($id, function(array $data) use ($session, $onLoad):void{
			$session->__setData($data);
			$event = new SessionCreationEvent($session);
			$event->call();

			$event->getWaitGroup()->then(function() use ($onLoad, $session):void{
				$onLoad($session);
			});
			$this->loader->getLogger()->debug("Offline " . $session->getName() . " has been loaded");
		});
	}

	public function getSessionById(string $id):?OnlineSession{
		if(isset($this->onlineSessions[$id])) {
			return $this->onlineSessions[$id];
		}

		return null;
	}

	public function getSessionByName(string $name):?OnlineSession{
		$player = PlayerUtils::getPlayer($name);
		if($player !== null) {
			return $this->getSession($player);
		}

		return null;
	}

	public function saveSession(BaseSession $session):void{
		if($session instanceof OnlineSession) {
			unset($this->onlineSessions[$session->getPlayer()->getUniqueId()->toString()]);
		}

		$this->provider->savePlayer($session);
	}

}