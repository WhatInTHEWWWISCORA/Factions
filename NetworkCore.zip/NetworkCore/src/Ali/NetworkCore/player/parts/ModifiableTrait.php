<?php
declare(strict_types=1);

namespace Ali\NetworkCore\player\parts;

use Ali\NetworkCore\NetworkCore;
use function strtolower;

trait ModifiableTrait{

	protected int $lastLogin;
	protected array $onlineTime;
	protected array $blocks;

	public function setLastLogin(int $lastLogin):void{
		$this->lastLogin = $lastLogin;
	}

	public function addOnlineTime(int $time):void{
		$data = parent::getOnlineTime();
		$t = $data[$name = NetworkCore::getInstance()->getCoreConfig()->ServerName()] ?? 0;
		$this->onlineTime[$name] = $t + $time;
	}

	public function addBlock(string $player): void{
		$this->blocks[strtolower($player)] = true;
	}

	public function unblock(string $player): void{
		unset($this->blocks[strtolower($player)]);
	}

}