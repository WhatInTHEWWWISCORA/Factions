<?php
declare(strict_types=1);

namespace Ali\NetworkCore\player\parts;

use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\player\OnlineSession;
use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\data\InfoEntry;
use Ali\NetworkCore\utils\TimeUtils;
use pocketmine\utils\TextFormat as C;
use function time;

class SessionInfo extends InfoEntry{

	public function __construct(private BaseSession $session){

	}

	public function get():array{
		$session = $this->session;
		$online = $session instanceof OnlineSession;
		$lastLogin = $session->getLastLogin();
		$onlineTime = $session->getOnlineTime();
		$registration = $session->getRegistrationDate();
		$current = $session->getLastServer();

		$array = [
			"Status" => ($online ? C::GREEN . "Online" : TimeUtils::FormatTime(time() - $lastLogin, C::WHITE, C::RED) . " ago"),
		];

		if($online) $array["Current Server"] = $current;

		$time = [];
		foreach($onlineTime as $key => $t){
			$time[ C::WHITE."  * ".C::RED.$key] = TimeUtils::FormatTime($t, C::WHITE, C::RED);
		}

		$array["Online Time"] = "\n".Messages::formatArray($time);
		$array["First Login"] = TimeUtils::FormatTime(time() - $registration, C::WHITE, C::RED) . " ago";

		return $array;
	}

}