<?php
declare(strict_types=1);

namespace Ali\NetworkCore\player;

use Ali\NetworkCore\player\parts\SessionInfo;
use Ali\NetworkCore\utils\data\InfoHolder;
use function is_array;
use function json_decode;
use function strtolower;
use function time;

class BaseSession{

	const ID = "playerId";
	const NAME = "name";
	const XUID = "xuid";
	const LAST_SERVER = "lastServer";
	const DISCORD_VERIFIED = "discordVerified";
	const DISCORD = "discord";
	const LAST_LOGIN = "lastLogin";
	const ONLINE_TIME = "onlineTime";
	const REGISTRATION = "registration";
	const BLOCKS = "blocks";

	protected string $name, $id, $xuid, $lastServer, $discord;

	protected int $lastLogin, $registration;
	protected array $onlineTime;

	protected bool $discordVerified;

	protected array $blocks;

	private InfoHolder $infoHolder;

	public function __construct(){
		$this->infoHolder = new InfoHolder();

		$this->infoHolder->add(new SessionInfo($this));
	}

	public function getInfoHolder():InfoHolder{
		return $this->infoHolder;
	}

	public function __setData(array $data):void{
		$data = $data[0] ?? [];
		$this->lastLogin = $data[self::LAST_LOGIN] ?? time();
		$this->id = $data[self::ID] ?? "";
		$this->name = $data[self::NAME] ?? "";
		$this->xuid = $data[self::XUID] ?? "";
		$this->lastServer = $data[self::LAST_SERVER] ?? "";
		$this->discordVerified = isset($data[self::DISCORD_VERIFIED]) && $data[self::DISCORD_VERIFIED] === 1;
		$this->discord = $data[self::DISCORD] ?? "";
		$onlineTime = json_decode($data[self::ONLINE_TIME] ?? "", true);
		if(!is_array($onlineTime)) $onlineTime = [];
		$this->onlineTime = $onlineTime;
		$this->registration = $data[self::REGISTRATION] ?? time();
		$this->blocks = isset($data[self::BLOCKS]) ? json_decode($data[self::BLOCKS], true) : [];
		$this->ready();
	}

	protected function ready():void{}

	public function getName():string{
		return $this->name;
	}

	public function getId():string{
		return $this->id;
	}

	public function getXuid():string{
		return $this->xuid;
	}

	public function getLastServer():string{
		return $this->lastServer;
	}

	public function isDiscordVerified():bool{
		return $this->discordVerified;
	}

	public function getDiscord(): string{
		return $this->discord;
	}

	public function getLastLogin():int{
		return $this->lastLogin;
	}

	public function getOnlineTime(): array{
		return $this->onlineTime;
	}

	public function getRegistrationDate():int{
		return $this->registration;
	}

	public function getBlocks():array{
		return $this->blocks;
	}

	public function isBlocked(string $player): bool{
		return isset($this->blocks[strtolower($player)]);
	}

}