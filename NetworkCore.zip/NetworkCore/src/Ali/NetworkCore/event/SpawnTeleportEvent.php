<?php
declare(strict_types=1);

namespace Ali\NetworkCore\event;

use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;
use pocketmine\player\Player;

class SpawnTeleportEvent extends Event{
	use CancellableTrait;

	const CAUSE_DEATH = 0;
	const CAUSE_COMMAND = 1;
	const CAUSE_JOIN = 2;

	public function __construct(private Player $player, private int $cause){
	}

	public function getCause():int{
		return $this->cause;
	}

	public function getPlayer():Player{
		return $this->player;
	}


}