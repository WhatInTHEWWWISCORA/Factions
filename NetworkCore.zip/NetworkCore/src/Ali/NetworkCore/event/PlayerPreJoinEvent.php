<?php
declare(strict_types=1);

namespace Ali\NetworkCore\event;

use Ali\NetworkCore\utils\data\WaitGroup;
use pocketmine\event\Event;
use pocketmine\player\Player;

class PlayerPreJoinEvent extends Event{

	private WaitGroup $waitGroup;

	public function __construct(private Player $player){
		$this->waitGroup = new WaitGroup();
	}

	public function getWaitGroup():WaitGroup{
		return $this->waitGroup;
	}

	public function getPlayer():Player{
		return $this->player;
	}

}