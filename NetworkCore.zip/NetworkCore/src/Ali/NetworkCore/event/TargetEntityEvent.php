<?php
declare(strict_types=1);

namespace Ali\NetworkCore\event;

use pocketmine\event\CancellableTrait;
use pocketmine\event\Event;
use pocketmine\player\Player;

class TargetEntityEvent extends Event{
	use CancellableTrait;

	public function __construct(private Player $player){

	}

	public function getPlayer():Player{
		return $this->player;
	}


}