<?php
declare(strict_types=1);


namespace Ali\NetworkCore\event;

use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\utils\data\WaitGroup;
use pocketmine\event\Event;

class SessionCreationEvent extends Event{

	private WaitGroup $waitGroup;

	public function __construct(private BaseSession $session){
		$this->waitGroup = new WaitGroup();
	}

	public function getSession():BaseSession{
		return $this->session;
	}

	public function getWaitGroup():WaitGroup{
		return $this->waitGroup;
	}

}