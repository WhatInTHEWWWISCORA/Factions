<?php
declare(strict_types=1);

namespace Ali\NetworkCore;

use Ali\NetworkCore\utils\world\WorldUtils;
use pocketmine\entity\Location;
use pocketmine\utils\Config;
use function is_string;

class CoreConfig{

	private Config $config;

	public function __construct(NetworkCore $core){
		$this->config = $core->getConfig();
	}

	public function DataBaseSettings(): array{
		return $this->config->get("database");
	}

	public function ServerName(): string{
		return $this->config->getNested("settings.server-name");
	}

	public function FallBackServer(): array{
		return $this->config->getNested("settings.fallback-server");
	}

	public function BannedPlayersAllowed(): bool{
		return $this->config->getNested("settings.allow-banned");
	}

	public function Spawn(): ?Location{
		$spawn = $this->config->getNested("settings.spawn");

		if(!is_string($spawn)){
			return null;
		}

		/** @var Location $result */
		$result = WorldUtils::DisposeVector($spawn);

		return $result;
	}

	public function setSpawn(Location $location): void{
		$this->config->setNested("settings.spawn",WorldUtils::HashLocation($location));
		$this->config->save();
	}

	public function AlwaysSpawn(): bool{
		return $this->config->getNested("settings.always-spawn");
	}

	public function DiscordAlerts(): bool{
		return $this->config->getNested("settings.discord.enabled");
	}

	public function DiscordTitle(): string{
		return $this->config->getNested("settings.discord.title");
	}

	public function DiscordIcon(): string{
		return $this->config->getNested("settings.discord.icon");
	}

	public function DiscordColor(): int{
		return $this->config->getNested("settings.discord.color");
	}

	public function MutesWebHook(): string{
		return $this->config->getNested("settings.discord.mutes");
	}

	public function UnMuteWebHook(): string{
		return $this->config->getNested("settings.discord.unmute");
	}

	public function TempBansWebHook(): string{
		return $this->config->getNested("settings.discord.tempbans");
	}

	public function PermBansWebHook(): string{
		return $this->config->getNested("settings.discord.permbans");
	}

	public function UnBanWebHook(): string{
		return $this->config->getNested("settings.discord.unban");
	}

	public function KickWebHook(): string{
		return $this->config->getNested("settings.discord.kick");
	}

}