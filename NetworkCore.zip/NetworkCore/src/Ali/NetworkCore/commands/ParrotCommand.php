<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\entity\Parrot;
use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as C;

class ParrotCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "parrot", "set a parrot on your shoulder");
	}

	protected function prepare():void{
		$this->addConstraint(new InGameRequiredConstraint($this));
		$this->setPermission("network.core.parrot");
		$this->registerArgument(0, new IntegerArgument("shoulder"));
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$parrot = new Parrot($sender->getLocation(), $args["shoulder"]);
		$parrot->spawnToAll();
		$parrot->sitOn($sender);
		$sender->sendMessage(C::GREEN."Enjoy your parrot ;D");
	}
}