<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;


use Ali\NetworkCore\NetworkCore;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseSubCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use function array_merge;
use function explode;
use function var_dump;

class ReplyCommand extends BaseSubCommand{

	public function __construct(Plugin $plugin){
		parent::__construct($plugin, "reply", "reply to your last DM", ["r"]);
	}

	protected function prepare():void{
		$this->addConstraint(new InGameRequiredConstraint($this));
		$this->registerArgument(0, new TextArgument("message"));
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$session = NetworkCore::getInstance()->getSessionManager()->getSession($sender);
		$cmd = Server::getInstance()->getCommandMap()->getCommand("tell");

		if($cmd !== null && $session->getLastSender() !== ""){
			$array = [];
			$array[] = $session->getLastSender();
			$array = array_merge($array, explode(" ", $args["message"]));
			$cmd->execute($sender, "tell", $array);
		}
	}
}