<?php /** @noinspection PhpUnhandledExceptionInspection */
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\commands\argument\TimeArgument;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Message;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Webhook;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\punishments\MuteEntry;
use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use function time;

class MuteCommand extends BaseCommand{

	public function __construct(private NetworkCore $core){
		parent::__construct($this->core, "mute", "mute a specific player for a set amount of time.", []);
	}

	protected function prepare():void{
		$this->setPermission("network.core.mute");
		$this->registerArgument(0, new RawStringArgument("player"));
		$this->registerArgument(1, new TimeArgument("length"));
		$this->registerArgument(2, new RawStringArgument("reason"));
	}


	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$player = $args["player"];
		$length = $args["length"];
		$reason = $args["reason"];

		$playerObject = PlayerUtils::getPlayer($player);

		if($playerObject instanceof Player) {
			$id = $playerObject->getUniqueId()->toString();
		}else{
			$this->core->getProvider()->getPlayerId($player, function(array $data) use ($player, $sender, $reason, $length):void{
				if($sender instanceof Player && !$sender->isConnected()) {
					return;
				}

				if($data === []) {
					$sender->sendMessage(Messages::PlayerNotFound($player));
					return;
				}

				$data = $data[0];
				$id = $data[BaseSession::ID];
				$this->mutePlayer($id, $player, $sender, $reason, $length);
			});
			return;
		}

		$this->mutePlayer($id, $player, $sender, $reason, $length);
	}

	private function mutePlayer(string $id, string $playerName, CommandSender $sender, string $reason, int $length):void{
		$playerObject = PlayerUtils::getPlayer($playerName);

		$muteEntry = MuteEntry::create($id, $sender instanceof Player ? $sender->getUniqueId()->toString() : $sender->getName(), $reason, time() + $length, false);
		if($playerObject !== null) {
			$this->core->getSessionManager()->getSession($playerObject)->setMuteEntry($muteEntry);
			$playerObject->sendMessage(Messages::Muted($reason, $length));
		}

		$embed = $this->core->getPunishmentsManager()->buildEmbed("Mute", $sender->getName(), $playerName, $reason, $length + time(), false);
		if($embed !== null) {
			$message = new Message();
			$message->setUsername("Mute");
			$message->addEmbed($embed);
			$settings = $this->core->getCoreConfig();
			$message->setAvatarURL($settings->DiscordIcon());

			$webHook = new Webhook($settings->MutesWebHook());
			$webHook->send($message);
		}


		$sender->sendMessage(Messages::PlayerMuted($playerName, $length));
		$this->core->getPunishmentsManager()->mutePlayer($id, $sender instanceof Player ? $sender->getUniqueId()->toString() : $sender->getName(), $reason, time() + $length);
	}

}