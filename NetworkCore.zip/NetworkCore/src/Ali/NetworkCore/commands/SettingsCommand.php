<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\player\SessionManager;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class SettingsCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "settings", "personalise settings to fit your style.", []);
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$member = SessionManager::get()->getSession($sender);
		$settings = $member->getSettings();

		$settings?->send($sender);
	}

	protected function prepare():void{
		$this->addConstraint(new InGameRequiredConstraint($this));
	}
}