<?php /** @noinspection PhpUnhandledExceptionInspection */
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\commands\argument\TimeArgument;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Message;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Webhook;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use function time;

class TempBanCommand extends BaseCommand{

	public function __construct(private NetworkCore $core){
		parent::__construct($this->core, "tempban", "ban a specific player for a set amount of time.", []);
	}

	protected function prepare():void{
		$this->setPermission("network.core.tempban");
		$this->registerArgument(0, new RawStringArgument("player"));
		$this->registerArgument(1, new TimeArgument("length"));
		$this->registerArgument(2, new RawStringArgument("reason", true));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$player = $args["player"];
		$length = $args["length"];
		$reason = $args["reason"] ?? "";

		$playerObject = PlayerUtils::getPlayer($player);
		if($playerObject instanceof Player) {
			$id = $playerObject->getUniqueId()->toString();
		}else{
			$this->core->getProvider()->getPlayerId($player, function(array $data) use ($player, $sender, $reason, $length):void{
				if($sender instanceof Player && !$sender->isConnected()) {
					return;
				}

				if($data === []) {
					$sender->sendMessage(Messages::PlayerNotFound($player));
					return;
				}
				$data = $data[0];

				$id = $data[BaseSession::ID];
				$this->banPlayer($id, $player, $sender, $reason, $length);

			});
			return;
		}

		$this->banPlayer($id, $player, $sender, $reason, $length);
	}

	private function banPlayer(string $id, string $playerName, CommandSender $sender, string $reason, $length):void{
		$this->core->getPunishmentsManager()->canBan($sender, function(bool $value) use ($sender, $reason, $playerName, $id, $length): bool{
			if(!$value) {
				return false;
			}

			$playerObject = PlayerUtils::getPlayer($playerName);
			$playerObject?->kick($reason);

			$embed = $this->core->getPunishmentsManager()->buildEmbed("Ban", $sender->getName(), $playerName, $reason, $length + time(), false);
			if($embed !== null) {
				$message = new Message();
				$message->setUsername("Ban");
				$message->addEmbed($embed);
				$settings = $this->core->getCoreConfig();
				$message->setAvatarURL($settings->DiscordIcon());

				$webHook = new Webhook($settings->TempBansWebHook());
				$webHook->send($message);
			}

			$sender->sendMessage(Messages::PlayerBanned($playerName, $length));
			$this->core->getPunishmentsManager()->banPlayer($id, $sender instanceof Player ? $sender->getUniqueId()->toString() : $sender->getName(), $reason, $length + time());
			return true;
		});
	}
}