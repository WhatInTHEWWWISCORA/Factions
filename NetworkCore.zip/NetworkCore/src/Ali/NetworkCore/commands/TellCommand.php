<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\player\OnlineSession;
use Ali\NetworkCore\player\SessionManager;
use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\TargetPlayerArgument;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

use pocketmine\utils\TextFormat as C;
use function is_null;

class TellCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "tell", "send a player a private message",["msg", "w"]);
	}


	protected function prepare():void{
		$this->registerArgument(0, new TargetPlayerArgument());
		$this->registerArgument(1, new TextArgument("message"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$p = $args["player"];

		$player = PlayerUtils::getPlayer($p);

		if(is_null($player)) {
			$sender->sendMessage(Messages::PlayerNotFound($p));
			return;
		}

		if($sender === $player) {
			$sender->sendMessage(C::RED . "You cannot send yourself private messages" . C::GRAY . ".");
			return;
		}

		$message = $args["message"];
		$s = $sender instanceof Player ? $sender->getName() : "";

		if($s === "") {
			$player->sendMessage($message);
			return;
		}


		/** @var Player $sender */
		$session = SessionManager::get()->getSession($player);


		if(!$session->getPlayer()->isConnected()) {
			$sender->sendMessage(Messages::PlayerNotFound($p));
			return;
		}

		if($session->isBlocked($sender->getUniqueId()->toString())) {
			$sender->sendMessage(Messages::BlockedFromMessages($p));
			return;
		}

		$session->getPlayer()->sendMessage(Messages::PrivateMessage($sender->getName(), "You", $message));
		$session->setLastSender($sender->getName());
		$sender->sendMessage(Messages::PrivateMessage("You", $session->getName(), $message));
	}
}