<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\utils\item\ItemUtils;
use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\args\TargetPlayerArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\lang\KnownTranslationFactory;
use pocketmine\permission\DefaultPermissionNames;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use function implode;

class EnchantCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "enchant", "add enchantment to an item");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$playerName = $args["player"];
		$enchantmentName = $args["enchantment"];

		$player = $sender->getServer()->getPlayerByPrefix($playerName);

		if($player === null) {
			$sender->sendMessage(KnownTranslationFactory::commands_generic_player_notFound()->prefix(TextFormat::RED));
			return;
		}

		$item = $player->getInventory()->getItemInHand();

		if($item->isNull()) {
			$sender->sendMessage(KnownTranslationFactory::commands_enchant_noItem());
			return;
		}

		$enchantment = StringToEnchantmentParser::getInstance()->parse($enchantmentName);
		if($enchantment === null) {
			$sender->sendMessage(KnownTranslationFactory::commands_enchant_notFound($enchantmentName));
			return;
		}

		$level = 1;
		if(isset($args["amount"])) {
			$level = $this->getBoundedInt($sender, $args["amount"], 1, $enchantment->getMaxLevel());
			if($level === null) {
				return;
			}
		}

		$item->addEnchantment(new EnchantmentInstance($enchantment, $level));
		ItemUtils::applyMetaLore($item);

		$player->getInventory()->setItemInHand($item);

		self::broadcastCommandMessage($sender, KnownTranslationFactory::commands_enchant_success($player->getName()));
	}

	protected function getBoundedInt(CommandSender $sender, int $input, int $min, int $max):?int{
		$v = $input;
		if($v > $max) {
			$sender->sendMessage(KnownTranslationFactory::commands_generic_num_tooBig((string) $input, (string) $max)->prefix(TextFormat::RED));
			return null;
		}
		if($v < $min) {
			$sender->sendMessage(KnownTranslationFactory::commands_generic_num_tooSmall((string) $input, (string) $min)->prefix(TextFormat::RED));
			return null;
		}

		return $v;
	}

	protected function prepare():void{
		$this->setPermission(implode(";", [
			DefaultPermissionNames::COMMAND_ENCHANT_SELF,
			DefaultPermissionNames::COMMAND_ENCHANT_OTHER
		]));
		$this->registerArgument(0, new TargetPlayerArgument());
		$this->registerArgument(1, new RawStringArgument("enchantment"));
		$this->registerArgument(2, new IntegerArgument("amount", true));
	}
}