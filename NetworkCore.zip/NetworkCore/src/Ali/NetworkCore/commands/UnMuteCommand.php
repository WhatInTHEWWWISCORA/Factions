<?php /** @noinspection PhpUnhandledExceptionInspection */
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\libraries\DiscordWebhookAPI\Message;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Webhook;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;

class UnMuteCommand extends BaseCommand{

	public function __construct(private NetworkCore $core){
		parent::__construct($this->core, "unmute", "unmute a specific player.", []);
	}

	protected function prepare():void{
		$this->setPermission("network.core.unmute");
		$this->registerArgument(0, new RawStringArgument("player"));
	}


	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$player = $args["player"];

		$playerObject = PlayerUtils::getPlayer($player);

		if($playerObject instanceof Player) {
			$id = $playerObject->getUniqueId()->toString();
		}else{
			$this->core->getProvider()->getPlayerId($player, function(array $data) use ($player, $sender):void{
				if($sender instanceof Player && !$sender->isConnected()) {
					return;
				}

				if($data === []) {
					$sender->sendMessage(Messages::PlayerNotFound($player));
					return;
				}

				$data = $data[0];
				$id = $data[BaseSession::ID];
				$this->core->getPunishmentsManager()->isPlayerMuted($id,function(array $data) use ($id,$player, $sender): void{
					if($sender instanceof Player && !$sender->isConnected()) {
						return;
					}

					if($data === []){
						$sender->sendMessage(C::RED . $player . " isn't muted.");
						return;
					}

					$this->unmutePlayer($id, $player, $sender);

				});
			});
			return;
		}

		$this->unmutePlayer($id, $player, $sender);
	}

	private function unmutePlayer(string $id, string $playerName, CommandSender $sender):void{
		$playerObject = PlayerUtils::getPlayer($playerName);

		if($playerObject !== null) {
			$this->core->getSessionManager()->getSession($playerObject)->setMuteEntry(null);
			$playerObject->sendMessage(Messages::UnMuted());
		}

		$embed = $this->core->getPunishmentsManager()->buildEmbed("UnMute", $sender->getName(), $playerName, "", -1, true);
		if($embed !== null) {
			$message = new Message();
			$message->setUsername("UnMute");
			$message->addEmbed($embed);
			$settings = $this->core->getCoreConfig();
			$message->setAvatarURL($settings->DiscordIcon());

			$webHook = new Webhook($settings->UnMuteWebHook());
			$webHook->send($message);
		}

		$sender->sendMessage(Messages::PlayerUnMuted($playerName));
		$this->core->getPunishmentsManager()->unmutePlayer($id);
	}
}