<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;


use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseSubCommand;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissionNames;
use pocketmine\plugin\Plugin;

class SayCommand extends BaseSubCommand{

	public function __construct(Plugin $plugin){
		parent::__construct($plugin, "say", "broadcast a message");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$message = $args["message"];
		$sender->getServer()->broadcastMessage($message);
	}

	protected function prepare():void{
		$this->setPermission(DefaultPermissionNames::COMMAND_SAY);
		$this->registerArgument(0, new TextArgument("message"));
	}


}