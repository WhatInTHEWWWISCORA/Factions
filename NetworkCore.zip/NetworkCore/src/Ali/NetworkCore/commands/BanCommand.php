<?php /** @noinspection PhpUnhandledExceptionInspection */
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\libraries\DiscordWebhookAPI\Message;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Webhook;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class BanCommand extends BaseCommand{

	public function __construct(private NetworkCore $core){
		parent::__construct($this->core, "ban", "ban a specific player.", []);
	}

	protected function prepare():void{
		$this->setPermission("network.core.ban");
		$this->registerArgument(0, new RawStringArgument("player"));
		$this->registerArgument(1, new RawStringArgument("reason"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$player = $args["player"];
		$reason = $args["reason"];

		$playerObject = PlayerUtils::getPlayer($player);
		if($playerObject instanceof Player) {
			$id = $playerObject->getUniqueId()->toString();
		}else{
			$this->core->getProvider()->getPlayerId($player, function(array $data) use ($player, $sender, $reason):void{
				if($sender instanceof Player && !$sender->isConnected()) {
					return;
				}

				$data = $data[0] ?? [];
				if($data === []) {
					$sender->sendMessage(Messages::PlayerNotFound($player));
					return;
				}

				$id = $data[BaseSession::ID];
				$this->banPlayer($id, $player, $sender, $reason);
			});
			return;
		}

		$this->banPlayer($id, $player, $sender, $reason);;
	}

	private function banPlayer(string $id, string $playerName, CommandSender $sender, string $reason):void{
		$this->core->getPunishmentsManager()->canBan($sender, function(bool $value) use ($sender, $reason, $playerName, $id): bool{
			if(!$value){
				return false;
			}

			$playerObject = PlayerUtils::getPlayer($playerName);
			$playerObject?->kick($reason);

			$embed = $this->core->getPunishmentsManager()->buildEmbed("Ban", $sender->getName(), $playerName, $reason, -1, true);
			if($embed !== null) {
				$message = new Message();
				$message->setUsername("Ban");
				$message->addEmbed($embed);
				$settings = $this->core->getCoreConfig();
				$message->setAvatarURL($settings->DiscordIcon());

				$webHook = new Webhook($settings->PermBansWebHook());
				$webHook->send($message);
			}

			$sender->sendMessage(Messages::PlayerBanned($playerName));
			$this->core->getPunishmentsManager()->banPlayer($id, $sender instanceof Player ? $sender->getUniqueId()->toString() : $sender->getName(), $reason, 0, true);
			return true;
		});
	}
}