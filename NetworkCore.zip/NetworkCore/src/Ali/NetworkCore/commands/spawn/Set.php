<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\spawn;

use Ali\NetworkCore\NetworkCore;
use CortexPE\Commando\BaseSubCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as C;

class Set extends BaseSubCommand{

	public function __construct(Plugin $plugin){
		parent::__construct($plugin, "set", "set the world spawn");
	}

	protected function prepare():void{
		$this->setPermission("network.core");
		$this->addConstraint(new InGameRequiredConstraint($this));
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		NetworkCore::getInstance()->getCoreConfig()->setSpawn($sender->getLocation());
		$sender->sendMessage(C::GREEN."Spawn location has been updated".C::GRAY.".");
	}
}