<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\spawn;

use Ali\Factions\features\teleport\TeleportManager;
use Ali\NetworkCore\event\SpawnTeleportEvent;
use Ali\NetworkCore\NetworkCore;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as C;
use function class_exists;
use function is_null;

class SpawnCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "spawn", "teleport to the server spawn.");
	}

	protected function prepare():void{
		$this->registerSubCommand(new Set($this->plugin));
		$this->addConstraint(new InGameRequiredConstraint($this));
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$spawn = NetworkCore::getInstance()->getCoreConfig()->Spawn();

		if(is_null($spawn)) {
			$sender->sendMessage(C::RED . "Spawn isn't set" . C::GRAY . ".");
			return;
		}

		$event = new SpawnTeleportEvent($sender, SpawnTeleportEvent::CAUSE_COMMAND);
		$event->call();

		if(!$event->isCancelled()) {
			$sender->teleport($spawn);
			$sender->sendMessage(C::GREEN."You've been teleported to the spawn");
		}
	}
}