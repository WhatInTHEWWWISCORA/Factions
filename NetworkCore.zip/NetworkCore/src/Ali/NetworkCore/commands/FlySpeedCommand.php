<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use CortexPE\Commando\args\FloatArgument;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

class FlySpeedCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "flyspeed", "set your flight speed");
	}

	protected function prepare():void{
		$this->setPermission("network.core");
		$this->addConstraint(new InGameRequiredConstraint($this));
		$this->registerArgument(0, new FloatArgument("speed"));
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$speed = $args["speed"];
		$this->syncAbilities($sender, $speed);
	}

	//todo change this when fly speed is implemented in pm
	private function syncAbilities(Player $for, float $flySpeed): void{
		$isOp = $for->hasPermission(DefaultPermissions::ROOT_OPERATOR);

	}
}