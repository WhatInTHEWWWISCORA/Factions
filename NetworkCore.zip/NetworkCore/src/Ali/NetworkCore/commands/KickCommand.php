<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\libraries\DiscordWebhookAPI\Message;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Webhook;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\TargetPlayerArgument;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\lang\KnownTranslationFactory;
use pocketmine\permission\DefaultPermissionNames;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;

class KickCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "kick", "kick a player from the server");
		$this->setPermission(DefaultPermissionNames::COMMAND_KICK);
	}

	protected function prepare():void{
		$this->registerArgument(0, new TargetPlayerArgument());
		$this->registerArgument(1, new TextArgument("reason"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$name = $args["player"];
		$reason = $args["reason"];
		$this->plugin->getPunishmentsManager()->canKick($sender, function(bool $value) use ($sender, $reason, $name):bool{
			if(!$value) {
				return false;
			}
			if(($player = PlayerUtils::getPlayer($name)) instanceof Player) {
				$player->kick("Kicked by admin." . ($reason !== "" ? " Reason: " . $reason : ""));
				if($reason !== "") {
					Command::broadcastCommandMessage($sender, KnownTranslationFactory::commands_kick_success_reason($player->getName(), $reason));
				}else{
					Command::broadcastCommandMessage($sender, KnownTranslationFactory::commands_kick_success($player->getName()));
				}

				$embed = NetworkCore::getInstance()->getPunishmentsManager()->buildEmbed("Kick", $sender->getName(), $player->getName(), $reason, -1, false);
				if($embed !== null) {
					$message = new Message();
					$message->setUsername("Kick");
					$message->addEmbed($embed);
					$settings = NetworkCore::getInstance()->getCoreConfig();
					$message->setAvatarURL($settings->DiscordIcon());

					$webHook = new Webhook($settings->KickWebHook());
					$webHook->send($message);
				}

				return true;
			}else{
				$sender->sendMessage(KnownTranslationFactory::commands_generic_player_notFound()->prefix(TextFormat::RED));
			}

			return false;
		});
	}

}