<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\player\OnlineSession;
use Ali\NetworkCore\player\SessionManager;
use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\TargetPlayerArgument;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as C;
use function is_null;

class UnBlockCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "unblock", "unblock a player to send you private messages");
	}

	protected function prepare():void{
		$this->addConstraint(new InGameRequiredConstraint($this));
		$this->registerArgument(0, new TargetPlayerArgument());
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$player = $args["player"];

		$p = PlayerUtils::getPlayer($player);

		if($sender === $p){
			$sender->sendMessage(C::RED."You cannot un-block yourself".C::GRAY.".");
			return;
		}

		if(is_null($p)) {
			NetworkCore::getInstance()->getProvider()->getPlayerId($player, function(array $data) use ($player, $sender):void{
				if(!$sender->isConnected()) {
					return;
				}

				if($data === []) {
					$sender->sendMessage(Messages::PlayerNotFound($player));
					return;
				}

				$id = $data[0][BaseSession::ID];

				$this->unBlock($sender, $id);
			});
			return;
		}

		$this->unBlock($sender, $p->getUniqueId()->toString());
	}

	private function unBlock(Player $player, string $target): void{
		$session = SessionManager::get()->getSession($player);

		if(!$session->isBlocked($target)) {
			$session->getPlayer()->sendMessage(Messages::NotBlocked());
			return;
		}

		$session->unblock($target);
		$session->getPlayer()->sendMessage(Messages::UnBlocked());
	}
}