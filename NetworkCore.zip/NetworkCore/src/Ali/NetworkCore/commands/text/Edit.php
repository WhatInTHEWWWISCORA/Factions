<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\text;

use Ali\NetworkCore\features\floatingText\FloatingTextHolder;
use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseSubCommand;
use pocketmine\command\CommandSender;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as C;

class Edit extends BaseSubCommand{

	public function __construct(Plugin $plugin){
		parent::__construct($plugin, "edit", "edit a floating text particle");
	}

	protected function prepare():void{
		$this->setPermission("network.core.ft");
		$this->registerArgument(0, new IntegerArgument("id"));
		$this->registerArgument(1, new TextArgument("text"));
	}


	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		if(FloatingTextHolder::getInstance()->editText($args["id"], $args["text"])){
			$sender->sendMessage(C::GREEN."Text has been edited".C::GRAY.".");
		}else{
			$sender->sendMessage(C::RED."Unknown text id".C::GRAY.".");
		}
	}

}