<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\text;

use Ali\NetworkCore\features\floatingText\FloatingTextHolder;
use Ali\NetworkCore\utils\commands\Messages;
use CortexPE\Commando\BaseSubCommand;
use pocketmine\command\CommandSender;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as C;
use function count;

class ListText extends BaseSubCommand{

	public function __construct(Plugin $plugin){
		parent::__construct($plugin, "list", "show floating texts list");
	}

	protected function prepare():void{
		$this->setPermission("network.core.ft");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$texts = FloatingTextHolder::getInstance()->getTexts();

		$string = [];
		foreach($texts as $text) {
			$string[] = $text->getText();
		}

		if(count($string) === 0){
			$sender->sendMessage(C::RED."There's no floating text".C::GRAY.".");
			return;
		}

		$sender->sendMessage(C::GREEN."Floating Text List".C::GRAY.":");
		$sender->sendMessage(Messages::formatArray($string));
	}
}