<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\text;

use Ali\NetworkCore\features\floatingText\FloatingTextHolder;
use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\BaseSubCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as C;

class Remove extends BaseSubCommand{

	public function __construct(Plugin $plugin){
		parent::__construct($plugin, "remove", "remove a floating text particle");
	}

	protected function prepare():void{
		$this->setPermission("network.core.ft");
		$this->addConstraint(new InGameRequiredConstraint($this));
		$this->registerArgument(0, new IntegerArgument("id"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		if(FloatingTextHolder::getInstance()->deleteText($args["id"])){
			$sender->sendMessage(C::GREEN."Text has been removed".C::GRAY.".");
		}else{
			$sender->sendMessage(C::RED."Unknown Text Id");
		}
	}
}