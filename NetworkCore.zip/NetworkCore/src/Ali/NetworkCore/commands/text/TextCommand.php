<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\text;

use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;

class TextCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "text", "manage floating texts");
	}

	protected function prepare():void{
		$this->setPermission("network.core.ft");
		$this->registerSubCommand(new Add($this->plugin));
		$this->registerSubCommand(new Remove($this->plugin));
		$this->registerSubCommand(new ListText($this->plugin));
		$this->registerSubCommand(new Edit($this->plugin));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
	}
}