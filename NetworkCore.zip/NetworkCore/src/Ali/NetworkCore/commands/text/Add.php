<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\text;

use Ali\NetworkCore\features\floatingText\FloatingTextHolder;
use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseSubCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as C;

class Add extends BaseSubCommand{

	public function __construct(Plugin $plugin){
		parent::__construct($plugin, "add", "add floating text particle");
	}

	protected function prepare():void{
		$this->setPermission("network.core.ft");
		$this->addConstraint(new InGameRequiredConstraint($this));
		$this->registerArgument(0, new TextArgument("text"));
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$text = $args["text"];
		FloatingTextHolder::getInstance()->addText($sender->getPosition(), $text);
		$sender->sendMessage(C::GREEN."Text has been added".C::GRAY.".");
	}
}