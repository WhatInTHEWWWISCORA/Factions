<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands\argument;

use Ali\NetworkCore\utils\TimeUtils;
use CortexPE\Commando\args\BaseArgument;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\AvailableCommandsPacket;

class TimeArgument extends BaseArgument{

	private int $value = 0;

	public function getNetworkType():int{
		return AvailableCommandsPacket::ARG_TYPE_STRING;
	}

	public function canParse(string $testString, CommandSender $sender):bool{
		$result = TimeUtils::parseTime($testString);
		if($result !== 0 && $result !== null) {
			$this->value = $result;
			return true;
		}

		return false;
	}

	public function parse(string $argument, CommandSender $sender){
		return $this->value;
	}

	public function getTypeName():string{
		return "time";
	}
}