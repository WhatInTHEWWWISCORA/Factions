<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\commands\spawn\SpawnCommand;
use Ali\NetworkCore\commands\text\TextCommand;
use Ali\NetworkCore\NetworkCore;

class Commands{

	public function __construct(private NetworkCore $core){
		$this->registerAll();
	}

	private function registerAll():void{
		$toUnregister = [
			"ban",
			"unban",
			"say",
			"pardon",
			"tell",
			"enchant",
			"ver",
			"kick",
			"me"];
		foreach($toUnregister as $commandName) {
			$cmd = $this->core->getServer()->getCommandMap()->getCommand($commandName);
			if($cmd !== null) {
				$this->core->getServer()->getCommandMap()->unregister($cmd);
			}
		}

		$commands = [
			new ProfileCommand($this->core),
			new BanCommand($this->core),
			new TempBanCommand($this->core),
			new PardonCommand($this->core),
			new MuteCommand($this->core),
			new UnMuteCommand($this->core),
			new PingCommand($this->core),
			new FlySpeedCommand($this->core),
			new TellCommand($this->core),
			new BlockCommand($this->core),
			new UnBlockCommand($this->core),
			new SpawnCommand($this->core),
			new EnchantCommand($this->core),
			new TextCommand($this->core),
			new SayCommand($this->core),
			new ReplyCommand($this->core),
			new KickCommand($this->core),
			new SettingsCommand($this->core),
			new ParrotCommand($this->core),
			new GenericCommand($this->core, "group"),
			new GenericCommand($this->core, "permission")];

		$this->core->getServer()->getCommandMap()->registerAll("main", $commands);
	}

}