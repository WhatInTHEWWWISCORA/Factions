<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\utils\commands\Messages;
use Ali\NetworkCore\utils\player\PlayerUtils;
use CortexPE\Commando\args\TargetPlayerArgument;
use CortexPE\Commando\BaseCommand;
use CortexPE\Commando\constraint\InGameRequiredConstraint;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as C;
use function is_null;

class PingCommand extends BaseCommand{

	public function __construct(PluginBase $plugin){
		parent::__construct($plugin, "ping", "displays player ping.", []);
	}

	protected function prepare():void{
		$this->addConstraint(new InGameRequiredConstraint($this));
		$this->registerArgument(0, new TargetPlayerArgument(true,"player"));
	}

	/**
	 * @param Player $sender
	 * @param string $aliasUsed
	 * @param array $args
	 * @return void
	 */
	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		if(isset($args["player"])){
			$p = PlayerUtils::getPlayer($args["player"]);

			if(is_null($p)){
				$sender->sendMessage(Messages::PlayerNotFound($args["player"]));
				return;
			}

			$sender->sendMessage(C::DARK_RED.$p->getName().C::GRAY."'s Ping".C::DARK_GRAY.": ".PlayerUtils::getPingColor($p->getNetworkSession()->getPing() ?? 1).($p->getNetworkSession()->getPing() ?? 1).C::WHITE."MS");
			return;
		}

		$sender->sendMessage(C::DARK_RED."Your Ping".C::DARK_GRAY.": ".PlayerUtils::getPingColor($sender->getNetworkSession()->getPing() ?? 1).($sender->getNetworkSession()->getPing() ?? 1).C::WHITE."MS");
	}
}