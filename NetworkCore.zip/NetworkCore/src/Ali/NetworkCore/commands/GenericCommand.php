<?php
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use CortexPE\Commando\args\TextArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;

class GenericCommand extends BaseCommand{

	public function __construct(PluginBase $plugin, string $name){
		parent::__construct($plugin, $name);
	}

	protected function prepare():void{
		$this->registerArgument(0, new TextArgument("text"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
	}
}