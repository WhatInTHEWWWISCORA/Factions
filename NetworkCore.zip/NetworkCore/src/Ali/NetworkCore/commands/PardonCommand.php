<?php /** @noinspection PhpUnhandledExceptionInspection */
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\libraries\DiscordWebhookAPI\Message;
use Ali\NetworkCore\libraries\DiscordWebhookAPI\Webhook;
use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\punishments\BanEntry;
use Ali\NetworkCore\utils\commands\Messages;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;
use function time;

class PardonCommand extends BaseCommand{

	public function __construct(private NetworkCore $core){
		parent::__construct($this->core, "pardon", "unban a specific player.", ["unban"]);
	}

	protected function prepare():void{
		$this->setPermission("network.core.pardon");
		$this->registerArgument(0, new RawStringArgument("player"));
		$this->registerArgument(1, new RawStringArgument("reason", true));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		$player = $args["player"];
		$reason = $args["reason"] ?? "";

		$this->core->getProvider()->getPlayerId($player, function(array $data) use ($player, $sender, $reason):void{
			if($sender instanceof Player && !$sender->isConnected()) {
				return;
			}


			if($data === []) {
				$sender->sendMessage(Messages::PlayerNotFound($player));
				return;
			}

			$data = $data[0] ?? [];
			$id = $data[BaseSession::ID];

			$this->core->getPunishmentsManager()->isPlayerBanned($id, function(?BanEntry $entry) use ($id, $player, $sender, $reason){
				if($sender instanceof Player && !$sender->isConnected()) {
					return;
				}

				if($entry !== null) {
					$this->core->getPunishmentsManager()->unbanPlayer($id);
					$sender->sendMessage(C::GREEN . "$player has been unbanned successfully.");

					$embed = $this->core->getPunishmentsManager()->buildEmbed("Pardon", $sender->getName(), $player, $reason, -1, true);
					if($embed !== null) {
						$message = new Message();
						$message->setUsername("Pardon");
						$message->addEmbed($embed);
						$settings = $this->core->getCoreConfig();
						$message->setAvatarURL($settings->DiscordIcon());
						$webHook = new Webhook($settings->UnBanWebHook());
						$webHook->send($message);
					}
				}else{
					$sender->sendMessage(C::RED . $player . " isn't banned.");
				}
			});
		});
	}
}