<?php /** @noinspection PhpUnhandledExceptionInspection */
declare(strict_types=1);

namespace Ali\NetworkCore\commands;

use Ali\NetworkCore\NetworkCore;
use Ali\NetworkCore\player\BaseSession;
use Ali\NetworkCore\utils\commands\Messages;
use CortexPE\Commando\args\RawStringArgument;
use CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as C;

class ProfileCommand extends BaseCommand{

	public function __construct(private NetworkCore $core){
		parent::__construct($core, "profile", "request a specific player info", ["i", "info"]);
	}

	protected function prepare():void{
		$this->registerArgument(0, new RawStringArgument("player", true));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args):void{
		if(isset($args["player"])) {
			$player = $args["player"];
		}else{
			$player = $sender->getName();
			if(!$sender instanceof Player) {
				$sender->sendMessage($this->getUsageMessage());
				return;
			}
		}

		$session = $this->core->getSessionManager()->getSessionByName($player);

		if($session !== null) {
			$sender->sendMessage(self::getInfoMessage($session));
			return;
		}

		$this->core->getProvider()->getPlayerId($player, function(array $data) use ($sender, $player):void{
			if($sender instanceof Player && !$sender->isConnected()) {
				return;
			}

			if($data === []) {
				$sender->sendMessage(Messages::PlayerNotFound($player));
				return;
			}

			$data = $data[0] ?? [];
			$id = $data[BaseSession::ID];

			$this->core->getSessionManager()->getOfflineSession($id, function(BaseSession $session) use ($sender): void{
				if($sender instanceof Player && !$sender->isConnected()) {
					return;
				}

				$sender->sendMessage(self::getInfoMessage($session));
			});
		});
	}

	public static function getInfoMessage(BaseSession $session):string{
		$name = $session->getName();
		$message = C::WHITE."$name".C::RED."'s Profile".C::GRAY.":";
		$message .= "\n" . Messages::formatArray($session->getInfoHolder()->get());

		return $message;
	}
}