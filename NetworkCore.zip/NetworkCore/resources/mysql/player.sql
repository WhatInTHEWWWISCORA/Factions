-- #!mysql
-- #{ core

-- #{ init-players
CREATE TABLE IF NOT EXISTS Players(
    playerId varchar(36) NOT NULL,
    name varchar(16) NOT NULL,
    xuid varchar(16) NOT NULL,
    online INT NOT NULL,
    lastServer varchar(36) NOT NULL,
    discordVerified int NOT NULL,
    discord varchar(36) NOT NULL,
    lastLogin int NOT NULL,
    onlineTime TEXT NOT NULL,
    registration int NOT NULL,
    blocks longtext NOT NULL,
    PRIMARY KEY (playerId)
);
-- #}

-- #{ get-player-id
-- #    :name string
SELECT playerId FROM Players WHERE name= :name;
-- #}

-- #{ get-player-xuid
-- #    :xuid string
SELECT * FROM Players WHERE xuid= :xuid;
-- #}

-- #{ load-player-id
-- #    :id string
SELECT * FROM Players WHERE playerId = :id;
-- #}

-- #{ load-player-name
-- #    :name string
SELECT * FROM Players WHERE name=:name;
-- #}

-- #{ update-online-status
-- #   :id string
-- #   :server string
UPDATE Players SET online= 1, lastServer= :server WHERE playerId= :id;
-- #}

-- #{ save-player
-- #    :id string
-- #    :name string
-- #    :xuid string
-- #    :online int
-- #    :lastServer string
-- #    :discordVerified int
-- #    :discord string
-- #    :lastLogin int
-- #    :onlineTime string
-- #    :registration int
-- #    :blocks string
INSERT INTO Players(playerId, name, xuid, online, lastServer, discordVerified, discord, lastLogin, onlineTime, registration, blocks) VALUES(:id, :name, :xuid, :online, :lastServer, :discordVerified, :discord, :lastLogin, :onlineTime, :registration, :blocks)
ON DUPLICATE KEY UPDATE name=VALUES(name), discordVerified=VALUES(discordVerified), discord=VALUES(discord), lastLogin=VALUES(lastLogin), onlineTime=VALUES(onlineTime), online=VALUES(online), lastServer=VALUES(lastServer), blocks=VALUES(blocks);
-- #}

-- #}