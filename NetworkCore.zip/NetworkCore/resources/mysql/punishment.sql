-- #!mysql
-- #{ core

-- #{ init-punishments-cooldown
CREATE TABLE IF NOT EXISTS PunishmentsCoolDown(
    playerId varchar(36) NOT NULL,
    bansStart int NOT NULL,
    bansCount int NOT NULL,
    KicksStart int NOT NULL,
    KicksCount int NOT NULL,
    PRIMARY KEY (playerId)
    );
-- #}

-- #{ select-player-cooldown
-- #    :id string
SELECT * FROM PunishmentsCoolDown WHERE playerId= :id
-- #}

-- #{ punishments-insert-player-cooldown
-- #    :id string
-- #    :bansStart int
-- #    :bansCount int
-- #    :KicksStart int
-- #    :KicksCount int
INSERT INTO PunishmentsCoolDown(playerId, bansStart, bansCount, KicksStart, KicksCount) VALUES(:id, :bansStart, :bansCount, :KicksStart, :KicksCount)
ON DUPLICATE KEY UPDATE bansStart=VALUES(bansStart), bansCount=VALUES(bansCount), KicksStart=VALUES(KicksStart), KicksCount=VALUES(KicksCount);
-- #}

-- #{ init-bans
CREATE TABLE IF NOT EXISTS Bans(
    playerId varchar(36) NOT NULL,
    Executor varchar(36) NOT NULL,
    Reason varchar(255) NOT NULL,
    Expiration int NOT NULL,
    Permanent int NOT NULL,
    PRIMARY KEY (playerId)
);
-- #}

-- #{ ban-player
-- #    :player string
-- #    :executor string
-- #    :reason string
-- #    :expiration int
-- #    :permanent int
INSERT INTO Bans(playerId, Executor, Reason, Expiration, Permanent) VALUES(:player, :executor, :reason, :expiration, :permanent)
ON DUPLICATE KEY UPDATE Executor=VALUES(Executor), Reason=VALUES(Reason), Expiration=VALUES(Expiration), Permanent=VALUES(Permanent);
-- #}

-- #{ unban-player
-- #    :player string
DELETE FROM Bans WHERE playerId= :player;
-- #}

-- #{ get-player-ban
-- #    :player string
SELECT * FROM Bans WHERE playerId= :player;
-- #}

-- #{ init-mutes
CREATE TABLE IF NOT EXISTS Mutes(
    playerId varchar(36) NOT NULL,
    Executor varchar(36) NOT NULL,
    Reason varchar(255) NOT NULL,
    Expiration int NOT NULL,
    PRIMARY KEY (playerId)
    );
-- #}

-- #{ mute-player
-- #    :player string
-- #    :executor string
-- #    :reason string
-- #    :expiration int
INSERT INTO Mutes(playerId, Executor, Reason, Expiration) VALUES(:player, :executor, :reason, :expiration)
    ON DUPLICATE KEY UPDATE Executor=VALUES(Executor), Reason=VALUES(Reason), Expiration=VALUES(Expiration);
-- #}

-- #{ unmute-player
-- #    :player string
DELETE FROM Mutes WHERE playerId= :player;
-- #}

-- #{ get-player-mute
-- #    :player string
SELECT * FROM Mutes WHERE playerId= :player;
-- #}

-- #}